package com.finsight.ai.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.finsight.ai.model.FinancialAnalysisResult
import com.finsight.ai.model.FinancialCalculator
import com.finsight.ai.model.MarginBand
import com.finsight.ai.model.RecommendationPriority
import com.finsight.ai.ui.components.ProfitMarginGauge
import com.finsight.ai.ui.components.ReportComparisonBars
import com.finsight.ai.ui.theme.AmberWarning
import com.finsight.ai.ui.theme.BorderHairline
import com.finsight.ai.ui.theme.CanvasBackground
import com.finsight.ai.ui.theme.CrimsonLoss
import com.finsight.ai.ui.theme.NavyPrimary
import com.finsight.ai.ui.theme.SlateBody
import com.finsight.ai.ui.theme.SlateMuted
import com.finsight.ai.ui.theme.TealAccent
import com.finsight.ai.ui.theme.TrackBackground
import java.util.Locale

@Composable
fun ReportsScreen(
    result: FinancialAnalysisResult,
    isSampleReport: Boolean,
    onEditInputs: () -> Unit,
    onBackToDashboard: () -> Unit
) {
    val statusColor = when {
        result.isZeroRevenue || result.isLoss -> CrimsonLoss
        result.marginBand == MarginBand.LOW_MARGIN || result.marginBand == MarginBand.BREAKEVEN -> AmberWarning
        else -> TealAccent
    }

    val marginDisplay = result.profitMarginPercent?.let {
        "${String.format(Locale.US, "%.2f", it)}%"
    } ?: "N/A (Zero Revenue)"

    val expenseRatioDisplay = result.expenseRatioPercent?.let {
        "${String.format(Locale.US, "%.1f", it)}%"
    } ?: "N/A"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasBackground)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = if (isSampleReport) {
                    "Sample Financial Report · Illustrative Data"
                } else {
                    "Calculated Financial Report"
                },
                color = TealAccent,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = result.companyName,
                color = NavyPrimary,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "${result.periodLabel} · Rule-Based Profitability Assessment",
                color = SlateMuted,
                fontSize = 13.sp
            )
        }

        // 2x2 Summary Cards
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ReportMetricCard(
                label = "Entered Revenue",
                value = FinancialCalculator.formatInr(result.revenue),
                subtext = "Gross operating inflow",
                accentColor = NavyPrimary,
                modifier = Modifier.weight(1f)
            )
            ReportMetricCard(
                label = "Entered Expenses",
                value = FinancialCalculator.formatInr(result.expenses),
                subtext = "Expense Ratio: $expenseRatioDisplay",
                accentColor = Color(0xFF1E293B),
                modifier = Modifier.weight(1f)
            )
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ReportMetricCard(
                label = if (result.isLoss) "Net Loss" else "Net Profit",
                value = FinancialCalculator.formatInr(result.netProfit),
                subtext = result.statusLabel,
                accentColor = statusColor,
                modifier = Modifier.weight(1f)
            )
            ReportMetricCard(
                label = "Profit Margin",
                value = marginDisplay,
                subtext = if (result.isZeroRevenue) "Division by zero prevented" else "(Net Profit / Revenue) × 100",
                accentColor = statusColor,
                modifier = Modifier.weight(1f)
            )
        }

        // Visual Charts Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, BorderHairline),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "Revenue vs. Expenses Balance",
                    color = NavyPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                ReportComparisonBars(
                    revenue = result.revenue,
                    expenses = result.expenses,
                    netProfit = result.netProfit
                )
                HorizontalDivider(color = BorderHairline)
                ProfitMarginGauge(
                    profitMarginPercent = result.profitMarginPercent,
                    isZeroRevenue = result.isZeroRevenue
                )
            }
        }

        // Executive Financial Summary & Formula Proof
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, BorderHairline),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Executive Financial Summary",
                        color = NavyPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = result.statusLabel,
                        color = statusColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Text(
                    text = result.summaryText,
                    color = SlateBody,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TrackBackground, RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Calculation Verification (MBA Accounting Audit)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NavyPrimary
                    )
                    Text(
                        text = "Net Profit = ${FinancialCalculator.formatInr(result.revenue)} − ${FinancialCalculator.formatInr(result.expenses)} = ${FinancialCalculator.formatInr(result.netProfit)}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = NavyPrimary
                    )
                    Text(
                        text = if (result.isZeroRevenue) {
                            "Profit Margin: Revenue is ₹0 → Undefined (N/A)"
                        } else {
                            "Profit Margin = (${FinancialCalculator.formatInr(result.netProfit)} / ${FinancialCalculator.formatInr(result.revenue)}) × 100 = $marginDisplay"
                        },
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = NavyPrimary
                    )
                }
            }
        }

        // Rule-Based Recommendations
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = "Practical Business Recommendations",
                color = NavyPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Generated using deterministic MBA rule-based profitability thresholds (offline rule engine, no live LLM inference).",
                color = SlateMuted,
                fontSize = 12.sp,
                lineHeight = 17.sp
            )
        }

        result.recommendations.forEach { rec ->
            val priorityColor = when (rec.priority) {
                RecommendationPriority.CRITICAL -> CrimsonLoss
                RecommendationPriority.ADVISORY -> AmberWarning
                RecommendationPriority.GROWTH -> NavyPrimary
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, BorderHairline),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = rec.category,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TealAccent
                        )
                        Text(
                            text = rec.priority.label,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = priorityColor
                        )
                    }
                    Text(
                        text = rec.title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                    Text(
                        text = rec.detail,
                        fontSize = 13.sp,
                        color = SlateBody,
                        lineHeight = 19.sp
                    )
                }
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
                onClick = onBackToDashboard,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Dashboard", color = NavyPrimary, fontWeight = FontWeight.SemiBold)
            }
            Button(
                onClick = onEditInputs,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
            ) {
                Text("Edit Inputs", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
    }
}

@Composable
private fun ReportMetricCard(
    label: String,
    value: String,
    subtext: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderHairline),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(text = label, color = SlateMuted, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(
                text = value,
                color = accentColor,
                fontSize = 18.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(text = subtext, color = SlateMuted, fontSize = 11.sp)
        }
    }
}
