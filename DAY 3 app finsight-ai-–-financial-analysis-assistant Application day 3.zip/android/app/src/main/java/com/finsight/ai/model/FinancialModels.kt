package com.finsight.ai.model

import java.text.NumberFormat
import java.util.Locale
import kotlin.math.abs

enum class MarginBand {
    ZERO_REVENUE,
    NET_LOSS,
    BREAKEVEN,
    LOW_MARGIN,
    HEALTHY_MARGIN,
    STRONG_MARGIN
}

enum class RecommendationPriority(val label: String) {
    CRITICAL("Critical"),
    ADVISORY("Advisory"),
    GROWTH("Growth")
}

data class FinancialInput(
    val companyName: String = "Apex SME Traders Pvt. Ltd.",
    val periodLabel: String = "FY 2025-26",
    val revenue: Double = 1_250_000.0,
    val expenses: Double = 940_000.0
)

data class InputValidationResult(
    val isValid: Boolean,
    val revenueError: String?,
    val expensesError: String?,
    val parsedRevenue: Double,
    val parsedExpenses: Double
)

data class RecommendationItem(
    val id: String,
    val title: String,
    val category: String,
    val priority: RecommendationPriority,
    val detail: String
)

data class FinancialAnalysisResult(
    val companyName: String,
    val periodLabel: String,
    val revenue: Double,
    val expenses: Double,
    val netProfit: Double,
    val isProfit: Boolean,
    val isLoss: Boolean,
    val isZeroRevenue: Boolean,
    val profitMarginPercent: Double?,
    val expenseRatioPercent: Double?,
    val marginBand: MarginBand,
    val statusLabel: String,
    val summaryText: String,
    val recommendations: List<RecommendationItem>
)

data class MonthlySamplePoint(
    val month: String,
    val revenue: Double,
    val expenses: Double
)

data class ExpenseBreakdownItem(
    val label: String,
    val sharePercent: Int
)

object FinancialCalculator {

    const val SAMPLE_COMPANY_NAME = "Aarav Precision Components Pvt. Ltd."
    const val SAMPLE_PERIOD_LABEL = "FY 2025-26 · Annual Sample Statement"

    val sampleMonthlySeries = listOf(
        MonthlySamplePoint("Oct", 380_000.0, 310_000.0),
        MonthlySamplePoint("Nov", 420_000.0, 325_000.0),
        MonthlySamplePoint("Dec", 465_000.0, 345_000.0),
        MonthlySamplePoint("Jan", 410_000.0, 332_000.0),
        MonthlySamplePoint("Feb", 490_000.0, 358_000.0),
        MonthlySamplePoint("Mar", 535_000.0, 370_000.0)
    )

    val sampleExpenseBreakdown = listOf(
        ExpenseBreakdownItem("Cost of Goods & Materials", 48),
        ExpenseBreakdownItem("Payroll & Operations", 28),
        ExpenseBreakdownItem("Rent, Utilities & Logistics", 15),
        ExpenseBreakdownItem("Sales, Admin & Compliance", 9)
    )

    val sampleTotalRevenue: Double
        get() = sampleMonthlySeries.sumOf { it.revenue }

    val sampleTotalExpenses: Double
        get() = sampleMonthlySeries.sumOf { it.expenses }

    fun formatInr(amount: Double, showDecimals: Boolean = false): String {
        val indianLocale = Locale.Builder().setLanguage("en").setRegion("IN").build()
        val formatter = NumberFormat.getNumberInstance(indianLocale).apply {
            minimumFractionDigits = if (showDecimals) 2 else 0
            maximumFractionDigits = if (showDecimals) 2 else 0
        }
        val absFormatted = formatter.format(abs(amount))
        return if (amount < 0.0) "-₹$absFormatted" else "₹$absFormatted"
    }

    fun validateInputs(revenueRaw: String, expensesRaw: String): InputValidationResult {
        val cleanRev = revenueRaw.replace(",", "").trim()
        val cleanExp = expensesRaw.replace(",", "").trim()

        var revenueError: String? = null
        var expensesError: String? = null

        val parsedRev = cleanRev.toDoubleOrNull()
        val parsedExp = cleanExp.toDoubleOrNull()

        when {
            cleanRev.isEmpty() -> {
                revenueError = "Enter total company revenue in ₹ (enter 0 if no revenue was recorded)."
            }
            parsedRev == null || !parsedRev.isFinite() -> {
                revenueError = "Revenue must be a valid numeric amount."
            }
            parsedRev < 0.0 -> {
                revenueError = "Revenue cannot be negative. Enter 0 or a positive rupee value."
            }
        }

        when {
            cleanExp.isEmpty() -> {
                expensesError = "Enter total company expenses in ₹."
            }
            parsedExp == null || !parsedExp.isFinite() -> {
                expensesError = "Expenses must be a valid numeric amount."
            }
            parsedExp < 0.0 -> {
                expensesError = "Expenses cannot be negative. Enter 0 or a positive rupee value."
            }
        }

        return InputValidationResult(
            isValid = revenueError == null && expensesError == null,
            revenueError = revenueError,
            expensesError = expensesError,
            parsedRevenue = if (parsedRev != null && parsedRev.isFinite()) parsedRev else 0.0,
            parsedExpenses = if (parsedExp != null && parsedExp.isFinite()) parsedExp else 0.0
        )
    }

    fun evaluate(input: FinancialInput): FinancialAnalysisResult {
        val cleanName = input.companyName.trim().ifEmpty { "Your Enterprise" }
        val cleanPeriod = input.periodLabel.trim().ifEmpty { "Current Reporting Period" }
        val revenue = input.revenue
        val expenses = input.expenses

        // Formula 1: Net Profit = Revenue - Expenses
        val netProfit = revenue - expenses
        val isZeroRevenue = revenue == 0.0
        val isProfit = netProfit > 0.0
        val isLoss = netProfit < 0.0

        // Formula 2: Profit Margin = (Net Profit / Revenue) * 100
        // Zero-revenue guard prevents division by zero
        val profitMarginPercent: Double? = if (isZeroRevenue) null else (netProfit / revenue) * 100.0
        val expenseRatioPercent: Double? = if (isZeroRevenue) null else (expenses / revenue) * 100.0

        val marginBand: MarginBand
        val statusLabel: String
        val summaryText: String

        when {
            isZeroRevenue -> {
                marginBand = MarginBand.ZERO_REVENUE
                statusLabel = if (expenses > 0.0) {
                    "Zero Revenue · Operating Burn"
                } else {
                    "Zero Revenue · No Activity"
                }
                summaryText = if (expenses > 0.0) {
                    "$cleanName recorded ₹0 in revenue against ${formatInr(expenses)} in expenses during $cleanPeriod, " +
                        "resulting in a net operating loss of ${formatInr(abs(netProfit))}. Profit margin is undefined because revenue is zero."
                } else {
                    "$cleanName recorded ₹0 in both revenue and expenses during $cleanPeriod. Profit margin cannot be computed when revenue is zero."
                }
            }
            netProfit < 0.0 -> {
                marginBand = MarginBand.NET_LOSS
                statusLabel = "Net Operating Loss"
                summaryText = "$cleanName incurred a net loss of ${formatInr(abs(netProfit))} " +
                    "(${String.format(Locale.US, "%.2f", profitMarginPercent)}% margin) for $cleanPeriod, " +
                    "as total expenses of ${formatInr(expenses)} exceeded revenue of ${formatInr(revenue)} by ${formatInr(abs(netProfit))}."
            }
            netProfit == 0.0 -> {
                marginBand = MarginBand.BREAKEVEN
                statusLabel = "Break-Even Position"
                summaryText = "$cleanName operated strictly at break-even for $cleanPeriod, with ${formatInr(revenue)} in revenue " +
                    "matching ${formatInr(expenses)} in total expenses (0.00% net margin)."
            }
            profitMarginPercent!! < 10.0 -> {
                marginBand = MarginBand.LOW_MARGIN
                statusLabel = "Positive · Thin Profit Margin"
                summaryText = "$cleanName generated a net profit of ${formatInr(netProfit)} on ${formatInr(revenue)} in revenue during $cleanPeriod. " +
                    "At ${String.format(Locale.US, "%.2f", profitMarginPercent)}%, the margin provides limited buffer against cost shocks."
            }
            profitMarginPercent <= 25.0 -> {
                marginBand = MarginBand.HEALTHY_MARGIN
                statusLabel = "Healthy Profitability"
                summaryText = "$cleanName achieved a healthy net profit of ${formatInr(netProfit)} and a " +
                    "${String.format(Locale.US, "%.2f", profitMarginPercent)}% profit margin for $cleanPeriod. " +
                    "Expenses consumed ${String.format(Locale.US, "%.1f", expenseRatioPercent)}% of revenue."
            }
            else -> {
                marginBand = MarginBand.STRONG_MARGIN
                statusLabel = "Strong Operating Margin"
                summaryText = "$cleanName delivered strong financial performance in $cleanPeriod, retaining " +
                    "${String.format(Locale.US, "%.2f", profitMarginPercent)}% of revenue as net profit (${formatInr(netProfit)}) " +
                    "while keeping expenses at ${String.format(Locale.US, "%.1f", expenseRatioPercent)}% of revenue."
            }
        }

        val recommendations = buildRuleBasedRecommendations(
            marginBand = marginBand,
            revenue = revenue,
            expenses = expenses,
            netProfit = netProfit
        )

        return FinancialAnalysisResult(
            companyName = cleanName,
            periodLabel = cleanPeriod,
            revenue = revenue,
            expenses = expenses,
            netProfit = netProfit,
            isProfit = isProfit,
            isLoss = isLoss,
            isZeroRevenue = isZeroRevenue,
            profitMarginPercent = profitMarginPercent,
            expenseRatioPercent = expenseRatioPercent,
            marginBand = marginBand,
            statusLabel = statusLabel,
            summaryText = summaryText,
            recommendations = recommendations
        )
    }

    private fun buildRuleBasedRecommendations(
        marginBand: MarginBand,
        revenue: Double,
        expenses: Double,
        netProfit: Double
    ): List<RecommendationItem> {
        return when (marginBand) {
            MarginBand.ZERO_REVENUE -> listOf(
                RecommendationItem(
                    id = "zr-1",
                    title = "Prioritize Immediate Revenue Activation",
                    category = "Top-Line Recovery",
                    priority = RecommendationPriority.CRITICAL,
                    detail = if (expenses > 0.0) {
                        "With ${formatInr(expenses)} in ongoing costs and ₹0 inflows, validate customer conversion bottlenecks and accelerate receivables or initial sales orders."
                    } else {
                        "Verify whether sales invoices for the period were deferred or unbilled, and log projected monthly revenue targets before committing fixed overheads."
                    }
                ),
                RecommendationItem(
                    id = "zr-2",
                    title = "Contain Fixed Monthly Burn",
                    category = "Cost Governance",
                    priority = RecommendationPriority.CRITICAL,
                    detail = "Pause discretionary marketing, non-essential subscriptions, and variable overtime until recurring monthly revenue covers core fixed obligations."
                ),
                RecommendationItem(
                    id = "zr-3",
                    title = "Establish Break-Even Runway Baseline",
                    category = "Working Capital",
                    priority = RecommendationPriority.ADVISORY,
                    detail = "Calculate minimum monthly sales required to match fixed costs and maintain at least 3 months of liquid cash reserves."
                )
            )

            MarginBand.NET_LOSS -> {
                val deficit = abs(netProfit)
                val requiredCutPct = if (expenses > 0.0) {
                    String.format(Locale.US, "%.1f", (deficit / expenses) * 100.0)
                } else {
                    "0.0"
                }
                listOf(
                    RecommendationItem(
                        id = "nl-1",
                        title = "Close the Operating Deficit Gap",
                        category = "Cost Restructuring",
                        priority = RecommendationPriority.CRITICAL,
                        detail = "Expenses exceed revenue by ${formatInr(deficit)}. Reaching break-even requires reducing total costs by $requiredCutPct% or increasing top-line revenue by ${formatInr(deficit)}."
                    ),
                    RecommendationItem(
                        id = "nl-2",
                        title = "Audit High-Share Expense Heads",
                        category = "Margin Control",
                        priority = RecommendationPriority.CRITICAL,
                        detail = "Separate fixed overheads (rent, salaries) from variable unit costs (raw materials, logistics) and renegotiate vendor payment terms or bulk rates."
                    ),
                    RecommendationItem(
                        id = "nl-3",
                        title = "Re-evaluate Unit Pricing & Product Mix",
                        category = "Pricing Strategy",
                        priority = RecommendationPriority.ADVISORY,
                        detail = "Discontinue loss-making SKUs or discounted contracts where contribution margin is negative, and focus sales effort on higher-margin offerings."
                    )
                )
            }

            MarginBand.BREAKEVEN -> listOf(
                RecommendationItem(
                    id = "be-1",
                    title = "Build a Positive Safety Margin Above Break-Even",
                    category = "Profitability Target",
                    priority = RecommendationPriority.ADVISORY,
                    detail = "Revenue (${formatInr(revenue)}) exactly equals expenses (${formatInr(expenses)}). Target at least a 10% net profit cushion (${formatInr(revenue * 0.10)}) to absorb GST, supplier, or seasonal fluctuations."
                ),
                RecommendationItem(
                    id = "be-2",
                    title = "Review Variable Cost Efficiency",
                    category = "Cost Discipline",
                    priority = RecommendationPriority.ADVISORY,
                    detail = "Even a 5% reduction in operating expenses would immediately unlock ${formatInr(expenses * 0.05)} in retained net profit without requiring additional sales volume."
                ),
                RecommendationItem(
                    id = "be-3",
                    title = "Track Contribution Margin by Line Item",
                    category = "Management Accounting",
                    priority = RecommendationPriority.GROWTH,
                    detail = "Segment revenue by customer tier or product line to identify which segments generate surplus cash versus those merely covering overhead."
                )
            )

            MarginBand.LOW_MARGIN -> listOf(
                RecommendationItem(
                    id = "lm-1",
                    title = "Strengthen Thin Profit Buffer (< 10% Margin)",
                    category = "Margin Expansion",
                    priority = RecommendationPriority.ADVISORY,
                    detail = "While profitable at ${formatInr(netProfit)}, a margin below 10% leaves the business vulnerable to raw material inflation or delayed customer payments. Aim toward 12–15%."
                ),
                RecommendationItem(
                    id = "lm-2",
                    title = "Optimize Procurement & Overhead Leakage",
                    category = "Cost Governance",
                    priority = RecommendationPriority.ADVISORY,
                    detail = "Audit recurring utility, logistics, and administrative expenses. Cutting 4% of operating costs would add ${formatInr(expenses * 0.04)} directly to bottom-line profit."
                ),
                RecommendationItem(
                    id = "lm-3",
                    title = "Improve Receivables Turnover",
                    category = "Working Capital",
                    priority = RecommendationPriority.GROWTH,
                    detail = "Enforce stricter credit periods (e.g., Net-15 or Net-30) so thin accounting profits convert into usable operating cash flow."
                )
            )

            MarginBand.HEALTHY_MARGIN -> listOf(
                RecommendationItem(
                    id = "hm-1",
                    title = "Reinvest Surplus Wisely in Core Growth",
                    category = "Capital Allocation",
                    priority = RecommendationPriority.GROWTH,
                    detail = "With ${formatInr(netProfit)} in net profit (10%–25% margin band), consider allocating 20–30% of surplus toward high-ROI customer acquisition or process automation."
                ),
                RecommendationItem(
                    id = "hm-2",
                    title = "Maintain Operating Expense Discipline as Scale Increases",
                    category = "Cost Control",
                    priority = RecommendationPriority.ADVISORY,
                    detail = "Ensure overhead hiring and fixed lease commitments grow slower than revenue so operating leverage improves further next quarter."
                ),
                RecommendationItem(
                    id = "hm-3",
                    title = "Build Working Capital & Tax Reserve",
                    category = "Compliance & Liquidity",
                    priority = RecommendationPriority.ADVISORY,
                    detail = "Set aside estimated direct tax provisions and maintain an emergency liquidity reserve before distributing retained earnings."
                )
            )

            MarginBand.STRONG_MARGIN -> listOf(
                RecommendationItem(
                    id = "sm-1",
                    title = "Protect Competitive Moat & Pricing Power",
                    category = "Strategic Positioning",
                    priority = RecommendationPriority.GROWTH,
                    detail = "Retaining over 25% of revenue (${formatInr(netProfit)}) signals strong pricing power and lean cost control. Monitor customer retention to sustain this premium margin."
                ),
                RecommendationItem(
                    id = "sm-2",
                    title = "Evaluate Capacity Expansion or Debt Reduction",
                    category = "Balance Sheet Strength",
                    priority = RecommendationPriority.GROWTH,
                    detail = "Deploy excess free cash flow to retire high-interest working capital debt or fund capacity expansion with internal accruals rather than external borrowing."
                ),
                RecommendationItem(
                    id = "sm-3",
                    title = "Standardize Quarterly Benchmarking",
                    category = "Financial Governance",
                    priority = RecommendationPriority.ADVISORY,
                    detail = "Track return on capital employed (ROCE) alongside net profit margin to confirm that reinvested capital continues generating high returns."
                )
            )
        }
    }
}
