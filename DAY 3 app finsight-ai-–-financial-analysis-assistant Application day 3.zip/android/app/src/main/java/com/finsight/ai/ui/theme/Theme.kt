package com.finsight.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val NavyPrimary = Color(0xFF0A2540)
val NavySecondary = Color(0xFF163A5F)
val TealAccent = Color(0xFF0D9488)
val TealHover = Color(0xFF0F766E)
val TealBright = Color(0xFF14B8A6)
val TealSoft = Color(0xFF5EEAD4)
val SurfaceWhite = Color(0xFFFFFFFF)
val CanvasBackground = Color(0xFFF8FAFC)
val BorderHairline = Color(0xFFE2E8F0)
val TrackBackground = Color(0xFFF1F5F9)
val SlateText = Color(0xFF0F172A)
val SlateBody = Color(0xFF334155)
val SlateMuted = Color(0xFF64748B)
val CrimsonLoss = Color(0xFFDC2626)
val AmberWarning = Color(0xFFD97706)

private val FinSightColorScheme = lightColorScheme(
    primary = NavyPrimary,
    onPrimary = Color.White,
    secondary = TealAccent,
    onSecondary = Color.White,
    background = CanvasBackground,
    onBackground = SlateText,
    surface = SurfaceWhite,
    onSurface = SlateText,
    surfaceVariant = TrackBackground,
    onSurfaceVariant = SlateMuted,
    outline = BorderHairline,
    error = CrimsonLoss,
    onError = Color.White
)

private val FinSightTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 30.sp,
        lineHeight = 36.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp,
        lineHeight = 30.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp,
        lineHeight = 24.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        lineHeight = 21.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 12.sp,
        lineHeight = 16.sp
    )
)

@Composable
fun FinSightTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = FinSightColorScheme,
        typography = FinSightTypography,
        content = content
    )
}
