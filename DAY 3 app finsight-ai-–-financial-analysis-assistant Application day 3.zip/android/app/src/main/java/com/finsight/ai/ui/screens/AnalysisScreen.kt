package com.finsight.ai.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.finsight.ai.model.FinancialAnalysisResult
import com.finsight.ai.model.FinancialCalculator
import com.finsight.ai.model.FinancialInput
import com.finsight.ai.ui.theme.AmberWarning
import com.finsight.ai.ui.theme.BorderHairline
import com.finsight.ai.ui.theme.CanvasBackground
import com.finsight.ai.ui.theme.CrimsonLoss
import com.finsight.ai.ui.theme.NavyPrimary
import com.finsight.ai.ui.theme.SlateMuted
import com.finsight.ai.ui.theme.TealAccent
import com.finsight.ai.ui.theme.TealSoft
import java.util.Locale

private data class DemoPreset(
    val label: String,
    val companyName: String,
    val periodLabel: String,
    val revenue: String,
    val expenses: String
)

private val DEMO_PRESETS = listOf(
    DemoPreset("Healthy SME", "Sahyadri Agro Foods Pvt. Ltd.", "Q4 FY 2025-26", "1850000", "1480000"),
    DemoPreset("Thin Margin", "Metro Retail Distributors", "FY 2025-26", "2400000", "2232000"),
    DemoPreset("Operating Loss", "Narmada Textiles Unit II", "Q3 FY 2025-26", "920000", "1085000"),
    DemoPreset("Zero Revenue", "Vanguard SaaS Beta", "Pre-Launch Quarter", "0", "175000")
)

@Composable
fun AnalysisScreen(
    companyName: String,
    periodLabel: String,
    revenueText: String,
    expensesText: String,
    onCompanyNameChange: (String) -> Unit,
    onPeriodLabelChange: (String) -> Unit,
    onRevenueChange: (String) -> Unit,
    onExpensesChange: (String) -> Unit,
    onCalculateSuccess: (FinancialAnalysisResult) -> Unit
) {
    var submittedAttempt by remember { mutableStateOf(false) }
    val validation = FinancialCalculator.validateInputs(revenueText, expensesText)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasBackground)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = "Indian Rupee (₹) Financial Entry",
                color = TealAccent,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "Financial Analysis",
                color = NavyPrimary,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Enter your company's Revenue and Expenses in Indian Rupees (₹), then select Calculate to generate the Financial Report.",
                color = SlateMuted,
                fontSize = 13.sp,
                lineHeight = 19.sp
            )
        }

        // Input Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, BorderHairline),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = companyName,
                    onValueChange = onCompanyNameChange,
                    label = { Text("Company / Business Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = periodLabel,
                    onValueChange = onPeriodLabelChange,
                    label = { Text("Reporting Period") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = revenueText,
                    onValueChange = onRevenueChange,
                    label = { Text("Total Company Revenue (₹)") },
                    prefix = { Text("₹ ") },
                    supportingText = {
                        when {
                            submittedAttempt && validation.revenueError != null -> {
                                Text(validation.revenueError, color = CrimsonLoss)
                            }
                            validation.revenueError == null && revenueText.trim().isNotEmpty() && validation.parsedRevenue == 0.0 -> {
                                Text(
                                    "Zero revenue detected: Profit Margin will display as N/A (division by zero prevented).",
                                    color = AmberWarning
                                )
                            }
                            validation.revenueError == null && revenueText.trim().isNotEmpty() -> {
                                Text(
                                    "Formatted: ${FinancialCalculator.formatInr(validation.parsedRevenue)}",
                                    color = TealAccent,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    },
                    isError = submittedAttempt && validation.revenueError != null,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = expensesText,
                    onValueChange = onExpensesChange,
                    label = { Text("Total Company Expenses (₹)") },
                    prefix = { Text("₹ ") },
                    supportingText = {
                        when {
                            submittedAttempt && validation.expensesError != null -> {
                                Text(validation.expensesError, color = CrimsonLoss)
                            }
                            validation.expensesError == null && expensesText.trim().isNotEmpty() -> {
                                Text(
                                    "Formatted: ${FinancialCalculator.formatInr(validation.parsedExpenses)}",
                                    color = SlateMuted,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    },
                    isError = submittedAttempt && validation.expensesError != null,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            submittedAttempt = true
                            if (validation.isValid) {
                                val result = FinancialCalculator.evaluate(
                                    FinancialInput(
                                        companyName = companyName,
                                        periodLabel = periodLabel,
                                        revenue = validation.parsedRevenue,
                                        expenses = validation.parsedExpenses
                                    )
                                )
                                onCalculateSuccess(result)
                            }
                        },
                        modifier = Modifier
                            .weight(1.4f)
                            .height(50.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                    ) {
                        Text(
                            text = "Calculate",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            onCompanyNameChange("")
                            onPeriodLabelChange("FY 2025-26")
                            onRevenueChange("")
                            onExpensesChange("")
                            submittedAttempt = false
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Clear", color = NavyPrimary, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }

        // MBA Scenario Presets
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, BorderHairline),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Sample Scenarios for MBA Evaluation",
                    color = NavyPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DEMO_PRESETS.take(2).forEach { preset ->
                        OutlinedButton(
                            onClick = {
                                onCompanyNameChange(preset.companyName)
                                onPeriodLabelChange(preset.periodLabel)
                                onRevenueChange(preset.revenue)
                                onExpensesChange(preset.expenses)
                                submittedAttempt = false
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(preset.label, fontSize = 12.sp, color = NavyPrimary)
                        }
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DEMO_PRESETS.drop(2).forEach { preset ->
                        OutlinedButton(
                            onClick = {
                                onCompanyNameChange(preset.companyName)
                                onPeriodLabelChange(preset.periodLabel)
                                onRevenueChange(preset.revenue)
                                onExpensesChange(preset.expenses)
                                submittedAttempt = false
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(preset.label, fontSize = 12.sp, color = NavyPrimary)
                        }
                    }
                }
            }
        }

        // Live Formula Preview Card
        Card(
            colors = CardDefaults.cardColors(containerColor = NavyPrimary),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Live Calculation Preview",
                    color = TealSoft,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                if (validation.isValid) {
                    val netProfit = validation.parsedRevenue - validation.parsedExpenses
                    val marginText = if (validation.parsedRevenue == 0.0) {
                        "N/A (Zero Rev)"
                    } else {
                        "${String.format(Locale.US, "%.2f", (netProfit / validation.parsedRevenue) * 100.0)}%"
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Net Profit = Rev − Exp", fontSize = 12.sp, color = Color(0xFFCBD5E1))
                        Text(
                            text = FinancialCalculator.formatInr(netProfit),
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    HorizontalDivider(color = Color.White.copy(alpha = 0.12f))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Profit Margin = (NP / Rev) × 100", fontSize = 12.sp, color = Color(0xFFCBD5E1))
                        Text(
                            text = marginText,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = TealSoft
                        )
                    }
                } else {
                    Text(
                        text = "Enter valid non-negative rupee amounts for both Revenue and Expenses to preview the accounting formulas.",
                        fontSize = 12.sp,
                        color = Color(0xFFCBD5E1),
                        lineHeight = 18.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
    }
}
