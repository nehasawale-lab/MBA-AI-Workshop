package com.finsight.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.finsight.ai.model.FinancialAnalysisResult
import com.finsight.ai.model.FinancialCalculator
import com.finsight.ai.model.FinancialInput
import com.finsight.ai.ui.screens.AnalysisScreen
import com.finsight.ai.ui.screens.DashboardScreen
import com.finsight.ai.ui.screens.ReportsScreen
import com.finsight.ai.ui.screens.WelcomeScreen
import com.finsight.ai.ui.theme.CanvasBackground
import com.finsight.ai.ui.theme.FinSightTheme
import com.finsight.ai.ui.theme.NavyPrimary
import com.finsight.ai.ui.theme.SlateMuted
import com.finsight.ai.ui.theme.TealAccent

sealed class Screen(val route: String, val label: String) {
    data object Welcome : Screen("welcome", "Welcome")
    data object Dashboard : Screen("dashboard", "Dashboard")
    data object Analysis : Screen("analysis", "Analysis")
    data object Reports : Screen("reports", "Reports")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FinSightTheme {
                FinSightApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinSightApp() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Welcome.route

    var companyNameInput by remember { mutableStateOf("Apex SME Traders Pvt. Ltd.") }
    var periodLabelInput by remember { mutableStateOf("FY 2025-26") }
    var revenueInput by remember { mutableStateOf("1250000") }
    var expensesInput by remember { mutableStateOf("940000") }

    var isSampleReport by remember { mutableStateOf(true) }
    var analysisResult by remember {
        mutableStateOf(
            FinancialCalculator.evaluate(
                FinancialInput(
                    companyName = FinancialCalculator.SAMPLE_COMPANY_NAME,
                    periodLabel = FinancialCalculator.SAMPLE_PERIOD_LABEL,
                    revenue = FinancialCalculator.sampleTotalRevenue,
                    expenses = FinancialCalculator.sampleTotalExpenses
                )
            )
        )
    }

    val navigateSingleTop: (String) -> Unit = { route ->
        navController.navigate(route) {
            launchSingleTop = true
        }
    }

    Scaffold(
        containerColor = CanvasBackground,
        topBar = {
            if (currentRoute != Screen.Welcome.route) {
                CenterAlignedTopAppBar(
                    title = {
                        Text(
                            text = "FinSight AI",
                            fontWeight = FontWeight.Bold,
                            color = NavyPrimary
                        )
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = Color.White
                    )
                )
            }
        },
        bottomBar = {
            if (currentRoute != Screen.Welcome.route) {
                NavigationBar(containerColor = Color.White) {
                    val items = listOf(
                        Triple(Screen.Welcome, Icons.Rounded.Home, "Welcome"),
                        Triple(Screen.Dashboard, Icons.Rounded.Dashboard, "Dashboard"),
                        Triple(Screen.Analysis, Icons.Rounded.Analytics, "Analysis"),
                        Triple(Screen.Reports, Icons.Rounded.Assessment, "Reports")
                    )
                    items.forEach { (screen, icon, label) ->
                        val selected = currentRoute == screen.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = { navigateSingleTop(screen.route) },
                            icon = { Icon(imageVector = icon, contentDescription = label) },
                            label = { Text(text = label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = TealAccent,
                                selectedTextColor = NavyPrimary,
                                unselectedIconColor = SlateMuted,
                                unselectedTextColor = SlateMuted,
                                indicatorColor = TealAccent.copy(alpha = 0.14f)
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Welcome.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Welcome.route) {
                WelcomeScreen(
                    onGetStarted = { navigateSingleTop(Screen.Dashboard.route) },
                    onOpenAnalysis = { navigateSingleTop(Screen.Analysis.route) },
                    onOpenReports = { navigateSingleTop(Screen.Reports.route) }
                )
            }

            composable(Screen.Dashboard.route) {
                DashboardScreen(
                    onOpenAnalysis = { navigateSingleTop(Screen.Analysis.route) },
                    onViewSampleReport = {
                        isSampleReport = true
                        analysisResult = FinancialCalculator.evaluate(
                            FinancialInput(
                                companyName = FinancialCalculator.SAMPLE_COMPANY_NAME,
                                periodLabel = FinancialCalculator.SAMPLE_PERIOD_LABEL,
                                revenue = FinancialCalculator.sampleTotalRevenue,
                                expenses = FinancialCalculator.sampleTotalExpenses
                            )
                        )
                        navigateSingleTop(Screen.Reports.route)
                    }
                )
            }

            composable(Screen.Analysis.route) {
                AnalysisScreen(
                    companyName = companyNameInput,
                    periodLabel = periodLabelInput,
                    revenueText = revenueInput,
                    expensesText = expensesInput,
                    onCompanyNameChange = { companyNameInput = it },
                    onPeriodLabelChange = { periodLabelInput = it },
                    onRevenueChange = { revenueInput = it },
                    onExpensesChange = { expensesInput = it },
                    onCalculateSuccess = { result: FinancialAnalysisResult ->
                        isSampleReport = false
                        analysisResult = result
                        navigateSingleTop(Screen.Reports.route)
                    }
                )
            }

            composable(Screen.Reports.route) {
                ReportsScreen(
                    result = analysisResult,
                    isSampleReport = isSampleReport,
                    onEditInputs = { navigateSingleTop(Screen.Analysis.route) },
                    onBackToDashboard = { navigateSingleTop(Screen.Dashboard.route) }
                )
            }
        }
    }
}
