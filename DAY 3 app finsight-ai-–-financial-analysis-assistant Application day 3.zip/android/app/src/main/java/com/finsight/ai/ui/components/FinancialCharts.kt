package com.finsight.ai.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.finsight.ai.model.FinancialCalculator
import com.finsight.ai.model.MonthlySamplePoint
import com.finsight.ai.ui.theme.AmberWarning
import com.finsight.ai.ui.theme.BorderHairline
import com.finsight.ai.ui.theme.CrimsonLoss
import com.finsight.ai.ui.theme.NavyPrimary
import com.finsight.ai.ui.theme.SlateBody
import com.finsight.ai.ui.theme.SlateMuted
import com.finsight.ai.ui.theme.SlateText
import com.finsight.ai.ui.theme.TealAccent
import com.finsight.ai.ui.theme.TealBright
import com.finsight.ai.ui.theme.TrackBackground
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

@Composable
fun FinSightLogoMark(size: Dp = 52.dp) {
    Canvas(modifier = Modifier.size(size)) {
        val corner = size.toPx() * 0.25f
        drawRoundRect(
            color = NavyPrimary,
            cornerRadius = CornerRadius(corner, corner)
        )
        val w = this.size.width
        val h = this.size.height
        val barW = w * 0.105f

        // 3 Rising Financial Bars
        drawRoundRect(
            color = TealBright,
            topLeft = Offset(w * 0.23f, h * 0.54f),
            size = Size(barW, h * 0.23f),
            cornerRadius = CornerRadius(4f, 4f)
        )
        drawRoundRect(
            color = Color(0xFF2DD4BF),
            topLeft = Offset(w * 0.40f, h * 0.42f),
            size = Size(barW, h * 0.35f),
            cornerRadius = CornerRadius(4f, 4f)
        )
        drawRoundRect(
            color = Color.White,
            topLeft = Offset(w * 0.57f, h * 0.29f),
            size = Size(barW, h * 0.48f),
            cornerRadius = CornerRadius(4f, 4f)
        )

        // Upward Growth Line
        val strokeW = w * 0.055f
        drawLine(
            color = TealBright,
            start = Offset(w * 0.23f, h * 0.44f),
            end = Offset(w * 0.41f, h * 0.30f),
            strokeWidth = strokeW,
            cap = StrokeCap.Round
        )
        drawLine(
            color = TealBright,
            start = Offset(w * 0.41f, h * 0.30f),
            end = Offset(w * 0.54f, h * 0.37f),
            strokeWidth = strokeW,
            cap = StrokeCap.Round
        )
        drawLine(
            color = TealBright,
            start = Offset(w * 0.54f, h * 0.37f),
            end = Offset(w * 0.75f, h * 0.21f),
            strokeWidth = strokeW,
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun MonthlyRevenueExpensesChart(data: List<MonthlySamplePoint>) {
    var selectedIdx by remember { mutableIntStateOf(data.lastIndex.coerceAtLeast(0)) }
    val activePoint = data.getOrNull(selectedIdx) ?: return
    val maxValue = data.maxOfOrNull { max(it.revenue, it.expenses) }?.coerceAtLeast(1.0) ?: 1.0

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Legend & Active Month Summary
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(NavyPrimary, RoundedCornerShape(2.dp))
                    )
                    Text("Revenue", fontSize = 12.sp, color = SlateBody, fontWeight = FontWeight.Medium)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(TealAccent, RoundedCornerShape(2.dp))
                    )
                    Text("Expenses", fontSize = 12.sp, color = SlateBody, fontWeight = FontWeight.Medium)
                }
            }

            Text(
                text = "${activePoint.month}: Profit ${FinancialCalculator.formatInr(activePoint.revenue - activePoint.expenses)}",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                color = TealAccent
            )
        }

        // Grouped Bar Canvas
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(170.dp)
        ) {
            val topPad = 12f
            val bottomPad = 8f
            val plotH = size.height - topPad - bottomPad
            val groupW = size.width / data.size.coerceAtLeast(1)
            val barW = min(28f, groupW * 0.28f)

            // Horizontal reference lines (0%, 50%, 100%)
            listOf(0f, 0.5f, 1f).forEach { ratio ->
                val y = topPad + plotH * (1f - ratio)
                drawLine(
                    color = BorderHairline,
                    start = Offset(0f, y),
                    end = Offset(size.width, y),
                    strokeWidth = 1.5f
                )
            }

            data.forEachIndexed { idx, point ->
                val groupX = idx * groupW
                val centerX = groupX + groupW * 0.5f

                if (idx == selectedIdx) {
                    drawRoundRect(
                        color = TrackBackground,
                        topLeft = Offset(groupX + 4f, topPad),
                        size = Size(groupW - 8f, plotH),
                        cornerRadius = CornerRadius(10f, 10f)
                    )
                }

                val revH = ((point.revenue / maxValue) * plotH).toFloat()
                val expH = ((point.expenses / maxValue) * plotH).toFloat()

                drawRoundRect(
                    color = NavyPrimary,
                    topLeft = Offset(centerX - barW - 3f, topPad + plotH - revH),
                    size = Size(barW, revH),
                    cornerRadius = CornerRadius(6f, 6f)
                )
                drawRoundRect(
                    color = TealAccent,
                    topLeft = Offset(centerX + 3f, topPad + plotH - expH),
                    size = Size(barW, expH),
                    cornerRadius = CornerRadius(6f, 6f)
                )
            }
        }

        // Interactive Month Selectors
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            data.forEachIndexed { idx, point ->
                val isSelected = idx == selectedIdx
                Text(
                    text = point.month,
                    fontSize = 12.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    color = if (isSelected) NavyPrimary else SlateMuted,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSelected) TrackBackground else Color.Transparent)
                        .clickable { selectedIdx = idx }
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }

        Text(
            text = "Selected (${activePoint.month}): Rev ${FinancialCalculator.formatInr(activePoint.revenue)} · Exp ${FinancialCalculator.formatInr(activePoint.expenses)}",
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace,
            color = SlateMuted
        )
    }
}

@Composable
fun ReportComparisonBars(
    revenue: Double,
    expenses: Double,
    netProfit: Double
) {
    val maxVal = maxOf(revenue, expenses, abs(netProfit), 1.0)
    val rows = listOf(
        Triple("Total Revenue", revenue, NavyPrimary),
        Triple("Total Expenses", expenses, Color(0xFF475569)),
        Triple(if (netProfit < 0.0) "Net Loss" else "Net Profit", netProfit, if (netProfit < 0.0) CrimsonLoss else TealAccent)
    )

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        rows.forEach { (label, rawValue, barColor) ->
            val fraction = (abs(rawValue) / maxVal).toFloat().coerceIn(0f, 1f)
            val displayFraction = if (rawValue != 0.0) max(fraction, 0.03f) else 0f
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = label, fontSize = 12.sp, color = SlateBody, fontWeight = FontWeight.Medium)
                    Text(
                        text = FinancialCalculator.formatInr(rawValue),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = SlateText
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(TrackBackground)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(displayFraction)
                            .fillMaxHeight()
                            .background(barColor)
                    )
                }
            }
        }
    }
}

@Composable
fun ProfitMarginGauge(
    profitMarginPercent: Double?,
    isZeroRevenue: Boolean
) {
    val normalized = when {
        profitMarginPercent == null -> 0f
        profitMarginPercent >= 0.0 -> (min(profitMarginPercent, 50.0) / 50.0).toFloat()
        else -> (min(abs(profitMarginPercent), 50.0) / 50.0).toFloat()
    }

    val arcColor = when {
        isZeroRevenue || profitMarginPercent == null -> Color(0xFF94A3B8)
        profitMarginPercent < 0.0 -> CrimsonLoss
        profitMarginPercent < 10.0 -> AmberWarning
        else -> TealAccent
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .width(180.dp)
                .height(106.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Canvas(modifier = Modifier.size(160.dp)) {
                val stroke = Stroke(width = 24f, cap = StrokeCap.Round)
                drawArc(
                    color = BorderHairline,
                    startAngle = 180f,
                    sweepAngle = 180f,
                    useCenter = false,
                    style = stroke
                )
                drawArc(
                    color = arcColor,
                    startAngle = 180f,
                    sweepAngle = 180f * normalized,
                    useCenter = false,
                    style = stroke
                )
            }
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                Text(
                    text = profitMarginPercent?.let {
                        "${String.format(Locale.US, "%.1f", it)}%"
                    } ?: "N/A",
                    fontSize = 22.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = when {
                        isZeroRevenue -> "Zero Revenue"
                        profitMarginPercent != null && profitMarginPercent < 0.0 -> "Operating Loss"
                        else -> "Net Profit Margin"
                    },
                    fontSize = 11.sp,
                    color = SlateMuted
                )
            }
        }
    }
}
