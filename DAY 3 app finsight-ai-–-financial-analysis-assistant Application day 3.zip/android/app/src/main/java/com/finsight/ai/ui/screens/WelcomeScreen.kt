package com.finsight.ai.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.finsight.ai.ui.components.FinSightLogoMark
import com.finsight.ai.ui.theme.BorderHairline
import com.finsight.ai.ui.theme.CanvasBackground
import com.finsight.ai.ui.theme.NavyPrimary
import com.finsight.ai.ui.theme.SlateBody
import com.finsight.ai.ui.theme.SlateMuted
import com.finsight.ai.ui.theme.TealAccent
import com.finsight.ai.ui.theme.TealSoft
import com.finsight.ai.ui.theme.TrackBackground

@Composable
fun WelcomeScreen(
    onGetStarted: () -> Unit,
    onOpenAnalysis: () -> Unit,
    onOpenReports: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasBackground)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Primary Navy Hero Card
        Card(
            colors = CardDefaults.cardColors(containerColor = NavyPrimary),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    FinSightLogoMark(size = 54.dp)
                    Column {
                        Text(
                            text = "MBA Finance & Accounting Project",
                            color = TealSoft,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "FinSight AI",
                            color = Color.White,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Text(
                    text = "Financial Analysis Assistant for Small Business Owners & Finance Managers",
                    color = Color(0xFF99F6E4),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    lineHeight = 24.sp
                )

                Text(
                    text = "Evaluate company profitability in Indian Rupees (₹), monitor cost-to-revenue efficiency, and review structured, rule-based management accounting recommendations without opaque black-box claims.",
                    color = Color(0xFFE2E8F0),
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )

                HorizontalDivider(color = Color.White.copy(alpha = 0.14f))

                Button(
                    onClick = onGetStarted,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
                ) {
                    Text(
                        text = "Get Started",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.weight(0.05f))
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                        contentDescription = null,
                        tint = Color.White
                    )
                }

                OutlinedButton(
                    onClick = onOpenAnalysis,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f))
                ) {
                    Text(
                        text = "Jump to Calculator (₹)",
                        color = Color.White,
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp
                    )
                }
            }
        }

        // Core Accounting Formulas Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, BorderHairline),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Core Accounting Engine",
                    color = TealAccent,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Verified Financial Formulas",
                    color = NavyPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TrackBackground, RoundedCornerShape(12.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("01. Net Profitability", fontSize = 12.sp, color = SlateMuted)
                    Text(
                        text = "Net Profit = Revenue − Expenses",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = NavyPrimary
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TrackBackground, RoundedCornerShape(12.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("02. Margin Efficiency", fontSize = 12.sp, color = SlateMuted)
                    Text(
                        text = "Profit Margin = (Net Profit / Revenue) × 100",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = NavyPrimary
                    )
                    Text(
                        text = "Includes zero-revenue guard to prevent division by zero.",
                        fontSize = 12.sp,
                        color = SlateBody
                    )
                }
            }
        }

        // Connected Workflow Quick Cards
        Text(
            text = "Connected 4-Screen Workflow",
            color = NavyPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )

        WorkflowStepCard(
            stepNumber = "Screen 01",
            title = "Financial Dashboard",
            description = "Review illustrative sample revenue, expenses, net profit, and 6-month SME trends.",
            onClick = onGetStarted
        )
        WorkflowStepCard(
            stepNumber = "Screen 02",
            title = "Financial Analysis",
            description = "Enter company revenue and expenses in Indian Rupees (₹) with real-time validation.",
            onClick = onOpenAnalysis
        )
        WorkflowStepCard(
            stepNumber = "Screen 03",
            title = "Financial Reports",
            description = "View automated Net Profit/Loss, Profit Margin %, charts, and rule-based MBA advice.",
            onClick = onOpenReports
        )

        Spacer(modifier = Modifier.height(8.dp))
    }
}

@Composable
private fun WorkflowStepCard(
    stepNumber: String,
    title: String,
    description: String,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderHairline),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = stepNumber,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = TealAccent
            )
            Text(text = title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = NavyPrimary)
            Text(text = description, fontSize = 13.sp, color = SlateBody, lineHeight = 19.sp)
        }
    }
}
