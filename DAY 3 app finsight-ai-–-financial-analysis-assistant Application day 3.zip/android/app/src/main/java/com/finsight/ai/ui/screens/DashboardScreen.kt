package com.finsight.ai.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.finsight.ai.model.FinancialCalculator
import com.finsight.ai.ui.components.MonthlyRevenueExpensesChart
import com.finsight.ai.ui.theme.BorderHairline
import com.finsight.ai.ui.theme.CanvasBackground
import com.finsight.ai.ui.theme.NavyPrimary
import com.finsight.ai.ui.theme.SlateBody
import com.finsight.ai.ui.theme.SlateMuted
import com.finsight.ai.ui.theme.TealAccent
import com.finsight.ai.ui.theme.TrackBackground
import java.util.Locale

@Composable
fun DashboardScreen(
    onOpenAnalysis: () -> Unit,
    onViewSampleReport: () -> Unit
) {
    val monthly = FinancialCalculator.sampleMonthlySeries
    val sampleRevenue = FinancialCalculator.sampleTotalRevenue
    val sampleExpenses = FinancialCalculator.sampleTotalExpenses
    val sampleNetProfit = sampleRevenue - sampleExpenses
    val sampleMargin = (sampleNetProfit / sampleRevenue) * 100.0
    val sampleExpenseRatio = (sampleExpenses / sampleRevenue) * 100.0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasBackground)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = "Sample Financial Data · Illustrative SME Ledger",
                color = TealAccent,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "Financial Dashboard",
                color = NavyPrimary,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "${FinancialCalculator.SAMPLE_COMPANY_NAME} · ${FinancialCalculator.SAMPLE_PERIOD_LABEL}",
                color = SlateMuted,
                fontSize = 13.sp
            )
        }

        // 2x2 Sample KPI Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            DashboardKpiCard(
                label = "Sample Revenue",
                value = FinancialCalculator.formatInr(sampleRevenue),
                note = "6-month cumulative inflow",
                accentColor = NavyPrimary,
                modifier = Modifier.weight(1f)
            )
            DashboardKpiCard(
                label = "Sample Expenses",
                value = FinancialCalculator.formatInr(sampleExpenses),
                note = "${String.format(Locale.US, "%.1f", sampleExpenseRatio)}% of revenue",
                accentColor = Color(0xFF1E293B),
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            DashboardKpiCard(
                label = "Sample Net Profit",
                value = FinancialCalculator.formatInr(sampleNetProfit),
                note = "Revenue minus Expenses",
                accentColor = TealAccent,
                modifier = Modifier.weight(1f)
            )
            DashboardKpiCard(
                label = "Sample Profit Margin",
                value = "${String.format(Locale.US, "%.2f", sampleMargin)}%",
                note = "Healthy SME band (10–25%)",
                accentColor = TealAccent,
                modifier = Modifier.weight(1f)
            )
        }

        // 6-Month Chart Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, BorderHairline),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Monthly Sample Revenue vs. Expenses",
                    color = NavyPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Tap any month below the chart to inspect illustrative values.",
                    color = SlateMuted,
                    fontSize = 12.sp
                )
                MonthlyRevenueExpensesChart(data = monthly)
            }
        }

        // Sample Expense Structure Breakdown
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, BorderHairline),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Sample Expense Structure",
                    color = NavyPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Illustrative breakdown of ${FinancialCalculator.formatInr(sampleExpenses)} total costs",
                    color = SlateMuted,
                    fontSize = 12.sp
                )

                FinancialCalculator.sampleExpenseBreakdown.forEach { item ->
                    val shareAmount = (sampleExpenses * item.sharePercent) / 100.0
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = item.label, fontSize = 12.sp, color = SlateBody, fontWeight = FontWeight.Medium)
                            Text(
                                text = "${item.sharePercent}% · ${FinancialCalculator.formatInr(shareAmount)}",
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold,
                                color = NavyPrimary
                            )
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(TrackBackground)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(item.sharePercent / 100f)
                                    .fillMaxHeight()
                                    .background(NavyPrimary)
                            )
                        }
                    }
                }
            }
        }

        // Sample Monthly Statement Ledger
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, BorderHairline),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Sample Monthly Statement Ledger (₹)",
                    color = NavyPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                HorizontalDivider(color = BorderHairline)
                monthly.forEach { row ->
                    val profit = row.revenue - row.expenses
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = row.month, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = NavyPrimary)
                        Text(
                            text = "Rev ${FinancialCalculator.formatInr(row.revenue)} · Profit ${FinancialCalculator.formatInr(profit)}",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TealAccent
                        )
                    }
                }
            }
        }

        Button(
            onClick = onOpenAnalysis,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
        ) {
            Text(
                text = "Analyze Your Company Figures",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
        }

        OutlinedButton(
            onClick = onViewSampleReport,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, NavyPrimary.copy(alpha = 0.35f))
        ) {
            Text(
                text = "Open Sample Financial Report",
                color = NavyPrimary,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp
            )
        }

        Spacer(modifier = Modifier.height(6.dp))
    }
}

@Composable
private fun DashboardKpiCard(
    label: String,
    value: String,
    note: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderHairline),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(text = label, color = SlateMuted, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(
                text = value,
                color = accentColor,
                fontSize = 18.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(text = note, color = SlateMuted, fontSize = 11.sp)
        }
    }
}
