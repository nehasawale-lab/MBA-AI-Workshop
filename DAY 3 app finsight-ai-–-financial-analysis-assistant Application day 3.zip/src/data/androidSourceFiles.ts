import mainActivityKt from '../../android/app/src/main/java/com/finsight/ai/MainActivity.kt?raw';
import financialModelsKt from '../../android/app/src/main/java/com/finsight/ai/model/FinancialModels.kt?raw';
import themeKt from '../../android/app/src/main/java/com/finsight/ai/ui/theme/Theme.kt?raw';
import financialChartsKt from '../../android/app/src/main/java/com/finsight/ai/ui/components/FinancialCharts.kt?raw';
import welcomeScreenKt from '../../android/app/src/main/java/com/finsight/ai/ui/screens/WelcomeScreen.kt?raw';
import dashboardScreenKt from '../../android/app/src/main/java/com/finsight/ai/ui/screens/DashboardScreen.kt?raw';
import analysisScreenKt from '../../android/app/src/main/java/com/finsight/ai/ui/screens/AnalysisScreen.kt?raw';
import reportsScreenKt from '../../android/app/src/main/java/com/finsight/ai/ui/screens/ReportsScreen.kt?raw';
import appBuildGradleKts from '../../android/app/build.gradle.kts?raw';
import rootBuildGradleKts from '../../android/build.gradle.kts?raw';
import settingsGradleKts from '../../android/settings.gradle.kts?raw';
import androidManifestXml from '../../android/app/src/main/AndroidManifest.xml?raw';

export interface AndroidSourceFile {
  path: string;
  fileName: string;
  summary: string;
  language: 'kotlin' | 'xml' | 'gradle';
  code: string;
}

export const ANDROID_SOURCE_FILES: AndroidSourceFile[] = [
  {
    path: 'android/app/src/main/java/com/finsight/ai/MainActivity.kt',
    fileName: 'MainActivity.kt',
    summary: 'Entry point hosting Jetpack Compose Navigation across Welcome, Dashboard, Analysis, and Reports screens.',
    language: 'kotlin',
    code: mainActivityKt,
  },
  {
    path: 'android/app/src/main/java/com/finsight/ai/model/FinancialModels.kt',
    fileName: 'FinancialModels.kt',
    summary: 'Accounting formulas, Indian Rupee (₹) formatting, input validation, zero-revenue guard, and rule-based MBA recommendations.',
    language: 'kotlin',
    code: financialModelsKt,
  },
  {
    path: 'android/app/src/main/java/com/finsight/ai/ui/theme/Theme.kt',
    fileName: 'Theme.kt',
    summary: 'Material 3 Navy Blue, White, and Teal color system and typography.',
    language: 'kotlin',
    code: themeKt,
  },
  {
    path: 'android/app/src/main/java/com/finsight/ai/ui/components/FinancialCharts.kt',
    fileName: 'FinancialCharts.kt',
    summary: 'Compose Canvas vector logo, 6-month grouped bar chart, comparison bars, and profit margin gauge.',
    language: 'kotlin',
    code: financialChartsKt,
  },
  {
    path: 'android/app/src/main/java/com/finsight/ai/ui/screens/WelcomeScreen.kt',
    fileName: 'WelcomeScreen.kt',
    summary: 'Screen 1: FinSight AI logo, app name, welcome message, verified formulas, and Get Started button.',
    language: 'kotlin',
    code: welcomeScreenKt,
  },
  {
    path: 'android/app/src/main/java/com/finsight/ai/ui/screens/DashboardScreen.kt',
    fileName: 'DashboardScreen.kt',
    summary: 'Screen 2: Financial Dashboard with labeled sample KPI cards, monthly chart, expense breakdown, and ledger.',
    language: 'kotlin',
    code: dashboardScreenKt,
  },
  {
    path: 'android/app/src/main/java/com/finsight/ai/ui/screens/AnalysisScreen.kt',
    fileName: 'AnalysisScreen.kt',
    summary: 'Screen 3: Financial Analysis inputs in ₹ with validation, demo presets, live formula preview, and Calculate button.',
    language: 'kotlin',
    code: analysisScreenKt,
  },
  {
    path: 'android/app/src/main/java/com/finsight/ai/ui/screens/ReportsScreen.kt',
    fileName: 'ReportsScreen.kt',
    summary: 'Screen 4: Financial Reports displaying Net Profit/Loss, Profit Margin, charts, audit proof, and rule-based advice.',
    language: 'kotlin',
    code: reportsScreenKt,
  },
  {
    path: 'android/app/build.gradle.kts',
    fileName: 'app/build.gradle.kts',
    summary: 'Module Gradle build configuration with Compose BOM, Material 3, and Navigation Compose.',
    language: 'gradle',
    code: appBuildGradleKts,
  },
  {
    path: 'android/build.gradle.kts',
    fileName: 'build.gradle.kts (Root)',
    summary: 'Top-level Gradle plugin declarations for AGP, Kotlin Android, and Compose Compiler.',
    language: 'gradle',
    code: rootBuildGradleKts,
  },
  {
    path: 'android/settings.gradle.kts',
    fileName: 'settings.gradle.kts',
    summary: 'Gradle repositories and :app module registration for Android Studio.',
    language: 'gradle',
    code: settingsGradleKts,
  },
  {
    path: 'android/app/src/main/AndroidManifest.xml',
    fileName: 'AndroidManifest.xml',
    summary: 'Application manifest registering FinSight AI and MainActivity launcher.',
    language: 'xml',
    code: androidManifestXml,
  },
];

export const APK_BUILD_STEPS = [
  {
    step: '01',
    title: 'Open the /android Folder in Android Studio',
    detail:
      'In Android Studio, select File -> Open and choose the /android directory inside this project. Gradle will sync using settings.gradle.kts and app/build.gradle.kts.',
  },
  {
    step: '02',
    title: 'Verify Android SDK 35 & JDK 17',
    detail:
      'Ensure Android SDK Platform 35 is installed in SDK Manager and Gradle JDK is set to JetBrains Runtime 17 in Settings -> Build Tools -> Gradle.',
  },
  {
    step: '03',
    title: 'Run on Emulator or Physical Phone',
    detail:
      'Select an Android 7.0+ (API 24+) emulator or USB-debugging device and click Run to test Welcome, Dashboard, Analysis, and Reports screens.',
  },
  {
    step: '04',
    title: 'Generate Debug APK (MBA Demo)',
    detail:
      'Select Build -> Build Bundle(s) / APK(s) -> Build APK(s). Android Studio generates android/app/build/outputs/apk/debug/app-debug.apk.',
  },
  {
    step: '05',
    title: 'Generate Signed Release APK',
    detail:
      'Select Build -> Generate Signed Bundle / APK -> APK, create/select a .jks keystore, and pick the release build variant for android/app/release/app-release.apk.',
  },
];
