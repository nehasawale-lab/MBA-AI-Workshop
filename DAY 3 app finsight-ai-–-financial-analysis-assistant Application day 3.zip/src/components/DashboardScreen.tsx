import React from 'react';
import { ArrowRight, Calculator, FileSpreadsheet, TrendingUp } from 'lucide-react';
import {
  SAMPLE_COMPANY_NAME,
  SAMPLE_DASHBOARD_TOTALS,
  SAMPLE_EXPENSE_BREAKDOWN,
  SAMPLE_MONTHLY_SERIES,
  SAMPLE_PERIOD_LABEL,
  formatINR,
} from '../types/finance';
import { MonthlyRevenueExpensesChart } from './Charts';

interface DashboardScreenProps {
  onOpenAnalysis: () => void;
  onViewSampleReport: () => void;
}

export function DashboardScreen({
  onOpenAnalysis,
  onViewSampleReport,
}: DashboardScreenProps) {
  const sampleRevenue = SAMPLE_DASHBOARD_TOTALS.revenue;
  const sampleExpenses = SAMPLE_DASHBOARD_TOTALS.expenses;
  const sampleNetProfit = sampleRevenue - sampleExpenses;
  const sampleMargin = (sampleNetProfit / sampleRevenue) * 100;
  const sampleExpenseRatio = (sampleExpenses / sampleRevenue) * 100;

  const kpiCards = [
    {
      label: 'Sample Revenue',
      value: formatINR(sampleRevenue),
      note: '6-month cumulative inflow · Sample Data',
      emphasis: 'text-[#0A2540]',
    },
    {
      label: 'Sample Expenses',
      value: formatINR(sampleExpenses),
      note: `${sampleExpenseRatio.toFixed(1)}% of sample revenue`,
      emphasis: 'text-slate-800',
    },
    {
      label: 'Sample Net Profit',
      value: formatINR(sampleNetProfit),
      note: 'Revenue minus Expenses · Surplus',
      emphasis: 'text-[#0D9488]',
    },
    {
      label: 'Sample Profit Margin',
      value: `${sampleMargin.toFixed(2)}%`,
      note: 'Healthy SME benchmark (10%–25%)',
      emphasis: 'text-[#0D9488]',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-[#0D9488]">
            Sample Financial Data · Illustrative SME Ledger
          </p>
          <h2 className="text-2xl sm:text-3xl font-bold text-[#0A2540] mt-1">
            Financial Dashboard
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            {SAMPLE_COMPANY_NAME} · {SAMPLE_PERIOD_LABEL}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={onViewSampleReport}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-[#0A2540] bg-white border border-slate-300 hover:border-[#0A2540] rounded-lg transition-colors cursor-pointer min-h-[44px]"
          >
            <FileSpreadsheet className="w-4 h-4" />
            Open Sample Report
          </button>
          <button
            type="button"
            onClick={onOpenAnalysis}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-[#0D9488] hover:bg-[#0F766E] rounded-lg transition-colors cursor-pointer min-h-[44px]"
          >
            <Calculator className="w-4 h-4" />
            Analyze Your Company
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 4 Financial KPI Cards */}
      <section aria-label="Sample Financial KPIs" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpiCards.map((card) => (
          <div
            key={card.label}
            className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between gap-3"
          >
            <p className="text-xs font-medium text-slate-500">{card.label}</p>
            <p className={`text-2xl font-bold font-mono tabular-nums ${card.emphasis}`}>
              {card.value}
            </p>
            <p className="text-xs text-slate-500">{card.note}</p>
          </div>
        ))}
      </section>

      {/* Main Analytics Split */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* 6-Month Chart */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between">
          <div className="flex flex-wrap items-start justify-between gap-2 mb-4">
            <div>
              <h3 className="text-base font-bold text-[#0A2540]">
                Monthly Sample Revenue vs. Expenses
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Hover over any month bar to inspect illustrative inflows, outflows, and net surplus
              </p>
            </div>
            <span className="inline-flex items-center gap-1 text-xs font-medium text-[#0D9488]">
              <TrendingUp className="w-4 h-4" />
              Sample 6-Month Series
            </span>
          </div>

          <MonthlyRevenueExpensesChart data={SAMPLE_MONTHLY_SERIES} />
        </div>

        {/* Sample Expense Structure Breakdown */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between">
          <div className="space-y-4">
            <div>
              <h3 className="text-base font-bold text-[#0A2540]">Sample Expense Structure</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Illustrative breakdown of {formatINR(sampleExpenses)} total costs
              </p>
            </div>

            <div className="space-y-4 pt-2">
              {SAMPLE_EXPENSE_BREAKDOWN.map((item) => {
                const rupeeShare = Math.round((sampleExpenses * item.sharePercent) / 100);
                return (
                  <div key={item.label} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-slate-700">{item.label}</span>
                      <span className="font-mono tabular-nums text-slate-900 font-semibold">
                        {item.sharePercent}% · {formatINR(rupeeShare)}
                      </span>
                    </div>
                    <div className="h-2 w-full bg-slate-100 rounded-sm overflow-hidden">
                      <div
                        className="h-full bg-[#0A2540] rounded-sm"
                        style={{ width: `${item.sharePercent}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-5 mt-5 border-t border-slate-100">
            <p className="text-xs text-slate-500 leading-relaxed">
              Figures shown above are illustrative sample data for demonstration. Enter your own
              company values on the Financial Analysis screen to generate a custom report.
            </p>
          </div>
        </div>
      </section>

      {/* Sample Monthly Ledger Table */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-[#0A2540]">
              Sample Monthly Statement Ledger
            </h3>
            <p className="text-xs text-slate-500">
              Illustrative monthly figures in Indian Rupees (₹) · Oct – Mar
            </p>
          </div>
          <span className="text-xs font-medium text-slate-500">Sample Data Only</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                <th className="text-left px-6 py-3">Month</th>
                <th className="text-right px-6 py-3">Sample Revenue (₹)</th>
                <th className="text-right px-6 py-3">Sample Expenses (₹)</th>
                <th className="text-right px-6 py-3">Net Profit (₹)</th>
                <th className="text-right px-6 py-3">Profit Margin</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {SAMPLE_MONTHLY_SERIES.map((row) => {
                const profit = row.revenue - row.expenses;
                const margin = (profit / row.revenue) * 100;
                return (
                  <tr key={row.month} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-6 py-3 font-medium text-[#0A2540]">{row.month}</td>
                    <td className="px-6 py-3 text-right font-mono tabular-nums text-slate-800">
                      {formatINR(row.revenue)}
                    </td>
                    <td className="px-6 py-3 text-right font-mono tabular-nums text-slate-600">
                      {formatINR(row.expenses)}
                    </td>
                    <td className="px-6 py-3 text-right font-mono tabular-nums font-semibold text-[#0D9488]">
                      {formatINR(profit)}
                    </td>
                    <td className="px-6 py-3 text-right font-mono tabular-nums text-slate-700">
                      {margin.toFixed(2)}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
