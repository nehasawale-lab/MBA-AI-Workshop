import React from 'react';
import { ArrowRight, BarChart3, Calculator, Code2, FileText } from 'lucide-react';
import { FinSightLogo } from './Charts';
import { AppScreen } from '../types/finance';

interface WelcomeScreenProps {
  onGetStarted: () => void;
  onNavigate: (screen: AppScreen) => void;
}

export function WelcomeScreen({ onGetStarted, onNavigate }: WelcomeScreenProps) {
  const workflowSteps: {
    index: string;
    title: string;
    description: string;
    screen: AppScreen;
    icon: React.ElementType;
  }[] = [
    {
      index: '01',
      title: 'Financial Dashboard',
      description:
        'Review illustrative sample revenue, expenses, net profit, and margin benchmarks across a 6-month SME ledger.',
      screen: 'dashboard',
      icon: BarChart3,
    },
    {
      index: '02',
      title: 'Financial Analysis',
      description:
        'Enter company revenue and expenses in Indian Rupees (₹) with real-time input validation and edge-case protection.',
      screen: 'analysis',
      icon: Calculator,
    },
    {
      index: '03',
      title: 'Financial Reports',
      description:
        'View automated Net Profit or Loss, Profit Margin %, visual charts, and deterministic rule-based MBA recommendations.',
      screen: 'reports',
      icon: FileText,
    },
  ];

  return (
    <div className="space-y-8">
      {/* Hero Split Container */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <div className="lg:col-span-7 bg-[#0A2540] text-white rounded-2xl p-8 sm:p-10 flex flex-col justify-between">
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <FinSightLogo size={52} />
              <div>
                <p className="text-xs font-medium tracking-wide text-teal-300">
                  MBA Finance &amp; Accounting Project
                </p>
                <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">
                  FinSight AI
                </h1>
              </div>
            </div>

            <div className="space-y-3 max-w-2xl">
              <h2 className="text-xl sm:text-2xl font-semibold text-teal-200 text-balance">
                Financial Analysis Assistant for Small Business Owners &amp; Finance Managers
              </h2>
              <p className="text-sm sm:text-base text-slate-200 leading-relaxed">
                Evaluate company profitability in Indian Rupees (₹), monitor cost-to-revenue
                efficiency, and review structured, rule-based management accounting recommendations
                without opaque black-box claims.
              </p>
            </div>
          </div>

          <div className="pt-8 mt-8 border-t border-white/15 flex flex-wrap items-center gap-4">
            <button
              type="button"
              onClick={onGetStarted}
              className="inline-flex items-center justify-center gap-2 bg-[#0D9488] hover:bg-[#0F766E] text-white font-semibold text-sm px-6 py-3 rounded-lg transition-colors cursor-pointer min-h-[44px]"
            >
              Get Started
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => onNavigate('analysis')}
              className="inline-flex items-center justify-center gap-2 bg-white/10 hover:bg-white/15 text-white font-medium text-sm px-5 py-3 rounded-lg transition-colors cursor-pointer min-h-[44px]"
            >
              Jump to Calculator (₹)
            </button>
            <button
              type="button"
              onClick={() => onNavigate('android-code')}
              className="inline-flex items-center justify-center gap-2 text-teal-200 hover:text-white font-medium text-sm px-3 py-2 transition-colors cursor-pointer min-h-[44px]"
            >
              <Code2 className="w-4 h-4" />
              Android Kotlin Source &amp; APK Guide
            </button>
          </div>
        </div>

        {/* Accounting Formulas & Academic Scope Panel */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-8 flex flex-col justify-between">
          <div className="space-y-6">
            <div>
              <p className="text-xs font-semibold text-[#0D9488]">Core Accounting Engine</p>
              <h3 className="text-xl font-bold text-[#0A2540] mt-1">
                Verified Financial Formulas
              </h3>
              <p className="text-sm text-slate-600 mt-1">
                Every report computes exact profitability ratios directly from user-entered figures.
              </p>
            </div>

            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <p className="text-xs font-medium text-slate-500">01. Net Profitability</p>
                <p className="font-mono text-sm sm:text-base font-semibold text-[#0A2540] mt-1">
                  Net Profit = Revenue − Expenses
                </p>
                <p className="text-xs text-slate-600 mt-1">
                  Positive values indicate operating profit; negative values are flagged as Net Loss.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <p className="text-xs font-medium text-slate-500">02. Margin Efficiency</p>
                <p className="font-mono text-sm sm:text-base font-semibold text-[#0A2540] mt-1">
                  Profit Margin = (Net Profit / Revenue) × 100
                </p>
                <p className="text-xs text-slate-600 mt-1">
                  Includes explicit zero-revenue protection to prevent division-by-zero errors.
                </p>
              </div>
            </div>
          </div>

          <div className="pt-6 mt-6 border-t border-slate-100 text-xs text-slate-500 flex flex-wrap items-center justify-between gap-2">
            <span>Currency: Indian Rupee (₹)</span>
            <span>Logic: Deterministic Rule-Based Advisory</span>
          </div>
        </div>
      </section>

      {/* Connected 4-Screen Workflow */}
      <section className="space-y-4">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h3 className="text-lg font-bold text-[#0A2540]">Connected Application Workflow</h3>
          <p className="text-xs text-slate-500">
            Select any screen below or click Get Started to step through the dashboard
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {workflowSteps.map((step) => {
            const Icon = step.icon;
            return (
              <button
                key={step.screen}
                type="button"
                onClick={() => onNavigate(step.screen)}
                className="text-left bg-white border border-slate-200 hover:border-[#0D9488] rounded-xl p-6 transition-colors cursor-pointer flex flex-col justify-between gap-4"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-semibold text-[#0D9488]">
                      Screen {step.index}
                    </span>
                    <Icon className="w-5 h-5 text-[#0A2540]" />
                  </div>
                  <h4 className="text-base font-bold text-[#0A2540]">{step.title}</h4>
                  <p className="text-sm text-slate-600 leading-relaxed">{step.description}</p>
                </div>
                <span className="text-xs font-semibold text-[#0D9488] inline-flex items-center gap-1">
                  Open screen
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </button>
            );
          })}
        </div>
      </section>
    </div>
  );
}
