import React, { useState } from 'react';
import { MonthlySamplePoint, formatINR } from '../types/finance';

export function FinSightLogo({ size = 40 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="FinSight AI Logo"
    >
      <rect width="48" height="48" rx="12" fill="#0A2540" />
      <rect x="11" y="26" width="5" height="11" rx="1.5" fill="#14B8A6" />
      <rect x="19" y="20" width="5" height="17" rx="1.5" fill="#2DD4BF" />
      <rect x="27" y="14" width="5" height="23" rx="1.5" fill="#FFFFFF" />
      <path
        d="M11 21L19.5 14.5L26 18L36 10"
        stroke="#14B8A6"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M31.5 10H36V14.5"
        stroke="#14B8A6"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function MonthlyRevenueExpensesChart({
  data,
}: {
  data: MonthlySamplePoint[];
}) {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const maxValue = Math.max(...data.flatMap((d) => [d.revenue, d.expenses]), 1);
  const chartHeight = 190;
  const chartWidth = 540;
  const leftPad = 56;
  const bottomPad = 28;
  const topPad = 16;
  const plotHeight = chartHeight - topPad - bottomPad;
  const plotWidth = chartWidth - leftPad - 12;
  const groupWidth = plotWidth / data.length;

  const yTicks = [0, 0.5, 1];
  const activePoint = hoveredIdx !== null ? data[hoveredIdx] : data[data.length - 1];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600">
        <div className="flex items-center gap-4">
          <span className="inline-flex items-center gap-1.5 font-medium text-slate-800">
            <span className="inline-block w-3 h-3 rounded-xs bg-[#0A2540]" />
            Revenue (₹)
          </span>
          <span className="inline-flex items-center gap-1.5 font-medium text-slate-800">
            <span className="inline-block w-3 h-3 rounded-xs bg-[#0D9488]" />
            Expenses (₹)
          </span>
        </div>
        <div className="font-mono tabular-nums text-slate-700">
          {activePoint.month}: Rev {formatINR(activePoint.revenue)} · Exp{' '}
          {formatINR(activePoint.expenses)} · Profit{' '}
          <span className="font-semibold text-[#0D9488]">
            {formatINR(activePoint.revenue - activePoint.expenses)}
          </span>
        </div>
      </div>

      <svg
        viewBox={`0 0 ${chartWidth} ${chartHeight}`}
        className="w-full h-auto overflow-visible"
        role="img"
        aria-label="Sample 6-month revenue and expenses bar chart"
      >
        {yTicks.map((tick) => {
          const y = topPad + plotHeight * (1 - tick);
          const tickVal = Math.round(maxValue * tick);
          return (
            <g key={tick}>
              <line
                x1={leftPad}
                y1={y}
                x2={chartWidth - 12}
                y2={y}
                stroke="#E2E8F0"
                strokeDasharray={tick === 0 ? undefined : '3 3'}
              />
              <text
                x={leftPad - 8}
                y={y + 4}
                textAnchor="end"
                className="fill-slate-400 text-[10px] font-mono tabular-nums"
              >
                {tick === 0 ? '₹0' : `₹${(tickVal / 100000).toFixed(1)}L`}
              </text>
            </g>
          );
        })}

        {data.map((point, idx) => {
          const groupX = leftPad + idx * groupWidth;
          const barW = Math.min(22, groupWidth * 0.3);
          const revH = (point.revenue / maxValue) * plotHeight;
          const expH = (point.expenses / maxValue) * plotHeight;
          const revX = groupX + groupWidth * 0.5 - barW - 2;
          const expX = groupX + groupWidth * 0.5 + 2;
          const isHovered = hoveredIdx === idx;

          return (
            <g
              key={point.month}
              onMouseEnter={() => setHoveredIdx(idx)}
              onMouseLeave={() => setHoveredIdx(null)}
              className="cursor-pointer"
            >
              <rect
                x={groupX + 4}
                y={topPad}
                width={groupWidth - 8}
                height={plotHeight}
                rx="6"
                fill={isHovered ? '#F1F5F9' : 'transparent'}
              />
              <rect
                x={revX}
                y={topPad + plotHeight - revH}
                width={barW}
                height={revH}
                rx="3"
                fill="#0A2540"
              />
              <rect
                x={expX}
                y={topPad + plotHeight - expH}
                width={barW}
                height={expH}
                rx="3"
                fill="#0D9488"
              />
              <text
                x={groupX + groupWidth * 0.5}
                y={chartHeight - 8}
                textAnchor="middle"
                className={`text-[11px] font-medium ${
                  isHovered ? 'fill-[#0A2540] font-semibold' : 'fill-slate-500'
                }`}
              >
                {point.month}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}

export function ReportComparisonChart({
  revenue,
  expenses,
  netProfit,
}: {
  revenue: number;
  expenses: number;
  netProfit: number;
}) {
  const maxVal = Math.max(revenue, expenses, Math.abs(netProfit), 1);
  const items = [
    {
      label: 'Total Revenue',
      value: revenue,
      display: formatINR(revenue),
      color: '#0A2540',
      pct: Math.max((revenue / maxVal) * 100, revenue > 0 ? 3 : 0),
    },
    {
      label: 'Total Expenses',
      value: expenses,
      display: formatINR(expenses),
      color: '#475569',
      pct: Math.max((expenses / maxVal) * 100, expenses > 0 ? 3 : 0),
    },
    {
      label: netProfit < 0 ? 'Net Loss' : 'Net Profit',
      value: Math.abs(netProfit),
      display: formatINR(netProfit),
      color: netProfit < 0 ? '#DC2626' : '#0D9488',
      pct: Math.max((Math.abs(netProfit) / maxVal) * 100, netProfit !== 0 ? 3 : 0),
    },
  ];

  return (
    <div className="space-y-4">
      {items.map((row) => (
        <div key={row.label} className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="font-medium text-slate-700">{row.label}</span>
            <span className="font-mono font-semibold tabular-nums text-slate-900">
              {row.display}
            </span>
          </div>
          <div className="h-3 w-full bg-slate-100 rounded-sm overflow-hidden">
            <div
              className="h-full rounded-sm transition-all duration-300"
              style={{ width: `${row.pct}%`, backgroundColor: row.color }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

export function ProfitMarginGauge({
  profitMarginPercent,
  isZeroRevenue,
}: {
  profitMarginPercent: number | null;
  isZeroRevenue: boolean;
}) {
  const clamped =
    profitMarginPercent === null
      ? 0
      : Math.max(-50, Math.min(50, profitMarginPercent));
  // Map -50%..+50% onto 0..180 degrees semicircle, or 0..100% fill if positive
  const normalized =
    profitMarginPercent === null
      ? 0
      : profitMarginPercent >= 0
      ? Math.min(profitMarginPercent, 50) / 50
      : Math.min(Math.abs(profitMarginPercent), 50) / 50;

  const radius = 64;
  const circumference = Math.PI * radius;
  const strokeDashoffset = circumference * (1 - normalized);

  const strokeColor = isZeroRevenue
    ? '#94A3B8'
    : clamped < 0
    ? '#DC2626'
    : clamped < 10
    ? '#D97706'
    : '#0D9488';

  return (
    <div className="flex flex-col items-center justify-center py-2">
      <svg width="176" height="104" viewBox="0 0 176 104" aria-label="Profit Margin Gauge">
        <path
          d="M 24 88 A 64 64 0 0 1 152 88"
          fill="none"
          stroke="#E2E8F0"
          strokeWidth="12"
          strokeLinecap="round"
        />
        <path
          d="M 24 88 A 64 64 0 0 1 152 88"
          fill="none"
          stroke={strokeColor}
          strokeWidth="12"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
        />
        <text
          x="88"
          y="74"
          textAnchor="middle"
          className="fill-[#0A2540] font-mono font-bold text-xl tabular-nums"
        >
          {profitMarginPercent === null
            ? 'N/A'
            : `${profitMarginPercent.toFixed(1)}%`}
        </text>
        <text
          x="88"
          y="92"
          textAnchor="middle"
          className="fill-slate-500 text-[10px] font-medium"
        >
          {isZeroRevenue
            ? 'Zero Revenue'
            : profitMarginPercent !== null && profitMarginPercent < 0
            ? 'Operating Loss'
            : 'Net Profit Margin'}
        </text>
      </svg>
    </div>
  );
}
