import React, { useState } from 'react';
import { AlertCircle, Calculator, RotateCcw } from 'lucide-react';
import {
  FinancialInput,
  formatINR,
  validateFinancialInputs,
} from '../types/finance';

interface AnalysisScreenProps {
  initialInput: FinancialInput;
  onCalculate: (input: FinancialInput) => void;
}

const DEMO_PRESETS: {
  label: string;
  companyName: string;
  periodLabel: string;
  revenue: string;
  expenses: string;
}[] = [
  {
    label: 'Healthy SME',
    companyName: 'Sahyadri Agro Foods Pvt. Ltd.',
    periodLabel: 'Q4 FY 2025–26',
    revenue: '1850000',
    expenses: '1480000',
  },
  {
    label: 'Thin Margin (<10%)',
    companyName: 'Metro Retail Distributors',
    periodLabel: 'FY 2025–26',
    revenue: '2400000',
    expenses: '2232000',
  },
  {
    label: 'Operating Loss',
    companyName: 'Narmada Textiles Unit II',
    periodLabel: 'Q3 FY 2025–26',
    revenue: '920000',
    expenses: '1085000',
  },
  {
    label: 'Zero Revenue Case',
    companyName: 'Vanguard SaaS Beta',
    periodLabel: 'Pre-Launch Quarter',
    revenue: '0',
    expenses: '175000',
  },
];

export function AnalysisScreen({ initialInput, onCalculate }: AnalysisScreenProps) {
  const [companyName, setCompanyName] = useState(initialInput.companyName);
  const [periodLabel, setPeriodLabel] = useState(initialInput.periodLabel);
  const [revenueText, setRevenueText] = useState(String(initialInput.revenue));
  const [expensesText, setExpensesText] = useState(String(initialInput.expenses));
  const [submittedAttempt, setSubmittedAttempt] = useState(false);

  const validation = validateFinancialInputs(revenueText, expensesText);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittedAttempt(true);
    if (!validation.isValid) return;

    onCalculate({
      companyName: companyName.trim() || 'Your Enterprise',
      periodLabel: periodLabel.trim() || 'Current Reporting Period',
      revenue: validation.parsedRevenue,
      expenses: validation.parsedExpenses,
    });
  };

  const handleReset = () => {
    setCompanyName('');
    setPeriodLabel('FY 2025–26');
    setRevenueText('');
    setExpensesText('');
    setSubmittedAttempt(false);
  };

  const applyPreset = (preset: (typeof DEMO_PRESETS)[number]) => {
    setCompanyName(preset.companyName);
    setPeriodLabel(preset.periodLabel);
    setRevenueText(preset.revenue);
    setExpensesText(preset.expenses);
    setSubmittedAttempt(false);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Left: Input Form */}
      <form
        onSubmit={handleSubmit}
        noValidate
        className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-6"
      >
        <div className="space-y-1">
          <p className="text-xs font-semibold text-[#0D9488]">
            Indian Rupee (₹) Financial Entry
          </p>
          <h2 className="text-2xl font-bold text-[#0A2540]">Financial Analysis</h2>
          <p className="text-sm text-slate-600">
            Enter your company&apos;s Revenue and Expenses in Indian Rupees (₹), then select{' '}
            <strong className="text-[#0A2540]">Calculate</strong> to generate the Financial Report.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label
              htmlFor="company-name"
              className="block text-xs font-semibold text-slate-700"
            >
              Company / Business Name
            </label>
            <input
              id="company-name"
              type="text"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              placeholder="e.g. Bharat Precision Works"
              className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-[#0D9488] focus:bg-white transition-colors"
            />
          </div>

          <div className="space-y-1.5">
            <label
              htmlFor="period-label"
              className="block text-xs font-semibold text-slate-700"
            >
              Reporting Period
            </label>
            <input
              id="period-label"
              type="text"
              value={periodLabel}
              onChange={(e) => setPeriodLabel(e.target.value)}
              placeholder="e.g. FY 2025–26"
              className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-[#0D9488] focus:bg-white transition-colors"
            />
          </div>
        </div>

        <div className="space-y-4">
          {/* Revenue Input */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label
                htmlFor="revenue-input"
                className="block text-xs font-semibold text-slate-700"
              >
                Total Company Revenue (₹)
              </label>
              {validation.revenueError === null && revenueText.trim() !== '' && (
                <span className="font-mono text-xs tabular-nums text-[#0D9488] font-medium">
                  {formatINR(validation.parsedRevenue)}
                </span>
              )}
            </div>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-mono font-semibold text-slate-500">
                ₹
              </span>
              <input
                id="revenue-input"
                type="text"
                inputMode="decimal"
                value={revenueText}
                onChange={(e) => setRevenueText(e.target.value)}
                placeholder="e.g. 1250000"
                aria-invalid={submittedAttempt && validation.revenueError !== null}
                className={`w-full pl-9 pr-4 py-3 font-mono tabular-nums text-base bg-slate-50 border rounded-lg focus:outline-none focus:bg-white transition-colors ${
                  submittedAttempt && validation.revenueError
                    ? 'border-[#DC2626] focus:border-[#DC2626]'
                    : 'border-slate-300 focus:border-[#0D9488]'
                }`}
              />
            </div>
            {submittedAttempt && validation.revenueError && (
              <p className="flex items-start gap-1.5 text-xs text-[#DC2626] font-medium">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{validation.revenueError}</span>
              </p>
            )}
            {validation.revenueError === null &&
              revenueText.trim() !== '' &&
              validation.parsedRevenue === 0 && (
                <p className="flex items-start gap-1.5 text-xs text-[#D97706] font-medium">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>
                    Zero revenue detected: Net Profit/Loss will be computed, and Profit Margin will
                    safely display as N/A (division by zero prevented).
                  </span>
                </p>
              )}
          </div>

          {/* Expenses Input */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label
                htmlFor="expenses-input"
                className="block text-xs font-semibold text-slate-700"
              >
                Total Company Expenses (₹)
              </label>
              {validation.expensesError === null && expensesText.trim() !== '' && (
                <span className="font-mono text-xs tabular-nums text-slate-700 font-medium">
                  {formatINR(validation.parsedExpenses)}
                </span>
              )}
            </div>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-mono font-semibold text-slate-500">
                ₹
              </span>
              <input
                id="expenses-input"
                type="text"
                inputMode="decimal"
                value={expensesText}
                onChange={(e) => setExpensesText(e.target.value)}
                placeholder="e.g. 940000"
                aria-invalid={submittedAttempt && validation.expensesError !== null}
                className={`w-full pl-9 pr-4 py-3 font-mono tabular-nums text-base bg-slate-50 border rounded-lg focus:outline-none focus:bg-white transition-colors ${
                  submittedAttempt && validation.expensesError
                    ? 'border-[#DC2626] focus:border-[#DC2626]'
                    : 'border-slate-300 focus:border-[#0D9488]'
                }`}
              />
            </div>
            {submittedAttempt && validation.expensesError && (
              <p className="flex items-start gap-1.5 text-xs text-[#DC2626] font-medium">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{validation.expensesError}</span>
              </p>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="pt-2 flex flex-wrap items-center gap-3">
          <button
            type="submit"
            className="inline-flex items-center justify-center gap-2 bg-[#0A2540] hover:bg-[#163A5F] text-white font-semibold text-sm px-6 py-3 rounded-lg transition-colors cursor-pointer min-h-[44px]"
          >
            <Calculator className="w-4 h-4 text-teal-300" />
            Calculate
          </button>
          <button
            type="button"
            onClick={handleReset}
            className="inline-flex items-center justify-center gap-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 font-medium text-sm px-4 py-3 rounded-lg transition-colors cursor-pointer min-h-[44px]"
          >
            <RotateCcw className="w-4 h-4" />
            Clear Fields
          </button>
        </div>
      </form>

      {/* Right: MBA Scenario Presets & Live Formula Preview */}
      <div className="lg:col-span-5 space-y-5">
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
          <div>
            <h3 className="text-base font-bold text-[#0A2540]">
              Sample Scenarios for Evaluation
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Load an illustrative test case to verify Profit, Thin Margin, Loss, and Zero Revenue
              handling
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {DEMO_PRESETS.map((preset) => (
              <button
                key={preset.label}
                type="button"
                onClick={() => applyPreset(preset)}
                className="text-left p-3.5 rounded-xl border border-slate-200 hover:border-[#0D9488] hover:bg-teal-50/40 transition-colors cursor-pointer"
              >
                <p className="text-xs font-bold text-[#0A2540]">{preset.label}</p>
                <p className="text-[11px] font-mono tabular-nums text-slate-500 mt-1">
                  Rev ₹{Number(preset.revenue).toLocaleString('en-IN')} · Exp ₹
                  {Number(preset.expenses).toLocaleString('en-IN')}
                </p>
              </button>
            ))}
          </div>
        </div>

        <div className="bg-[#0A2540] text-white rounded-2xl p-6 space-y-4">
          <h3 className="text-sm font-bold text-teal-300">Live Calculation Preview</h3>
          {validation.isValid ? (
            <div className="space-y-3 text-xs font-mono tabular-nums">
              <div className="flex justify-between py-1.5 border-b border-white/10">
                <span className="text-slate-300">Net Profit = Rev − Exp</span>
                <span className="font-semibold text-white">
                  {formatINR(validation.parsedRevenue - validation.parsedExpenses)}
                </span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-slate-300">Profit Margin = (NP / Rev) × 100</span>
                <span className="font-semibold text-teal-300">
                  {validation.parsedRevenue === 0
                    ? 'N/A (Zero Rev)'
                    : `${(
                        ((validation.parsedRevenue - validation.parsedExpenses) /
                          validation.parsedRevenue) *
                        100
                      ).toFixed(2)}%`}
                </span>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-300 leading-relaxed">
              Enter valid non-negative rupee amounts for both Revenue and Expenses to preview the
              accounting formulas before generating the report.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
