import React from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
  Printer,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';
import { FinancialReportResult, formatINR } from '../types/finance';
import { ProfitMarginGauge, ReportComparisonChart } from './Charts';

interface ReportsScreenProps {
  report: FinancialReportResult;
  isSampleReport: boolean;
  onEditInputs: () => void;
  onBackToDashboard: () => void;
}

export function ReportsScreen({
  report,
  isSampleReport,
  onEditInputs,
  onBackToDashboard,
}: ReportsScreenProps) {
  const statusAccent = report.isZeroRevenue || report.isLoss
    ? 'text-[#DC2626]'
    : report.marginBand === 'low_margin' || report.marginBand === 'breakeven'
    ? 'text-[#D97706]'
    : 'text-[#0D9488]';

  const StatusIcon = report.isLoss || report.isZeroRevenue
    ? TrendingDown
    : report.marginBand === 'low_margin' || report.marginBand === 'breakeven'
    ? AlertTriangle
    : TrendingUp;

  const marginDisplay =
    report.profitMarginPercent === null
      ? 'N/A (Zero Revenue)'
      : `${report.profitMarginPercent.toFixed(2)}%`;

  const expenseRatioDisplay =
    report.expenseRatioPercent === null
      ? 'N/A'
      : `${report.expenseRatioPercent.toFixed(1)}%`;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-[#0D9488]">
            {isSampleReport ? 'Sample Financial Report · Illustrative Data' : 'Calculated Financial Report'}
          </p>
          <h2 className="text-2xl sm:text-3xl font-bold text-[#0A2540] mt-1">
            {report.companyName}
          </h2>
          <p className="text-sm text-slate-600 mt-0.5">
            {report.periodLabel} · Rule-Based Profitability Assessment
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 no-print">
          <button
            type="button"
            onClick={onBackToDashboard}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-[#0A2540] bg-white border border-slate-300 hover:border-[#0A2540] rounded-lg transition-colors cursor-pointer min-h-[44px]"
          >
            <ArrowLeft className="w-4 h-4" />
            Dashboard
          </button>
          <button
            type="button"
            onClick={onEditInputs}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-[#0D9488] hover:bg-[#0F766E] rounded-lg transition-colors cursor-pointer min-h-[44px]"
          >
            Edit Inputs
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-[#0A2540] hover:bg-[#163A5F] rounded-lg transition-colors cursor-pointer min-h-[44px]"
          >
            <Printer className="w-4 h-4" />
            Print Report
          </button>
        </div>
      </div>

      {/* 4 Summary Metric Cards */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-2">
          <p className="text-xs font-medium text-slate-500">Entered Revenue</p>
          <p className="text-2xl font-bold font-mono tabular-nums text-[#0A2540]">
            {formatINR(report.revenue)}
          </p>
          <p className="text-xs text-slate-500">Gross operating inflow</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-2">
          <p className="text-xs font-medium text-slate-500">Entered Expenses</p>
          <p className="text-2xl font-bold font-mono tabular-nums text-slate-800">
            {formatINR(report.expenses)}
          </p>
          <p className="text-xs text-slate-500">Expense-to-Revenue: {expenseRatioDisplay}</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-2">
          <p className="text-xs font-medium text-slate-500">
            {report.isLoss ? 'Net Loss' : 'Net Profit'}
          </p>
          <p className={`text-2xl font-bold font-mono tabular-nums ${statusAccent}`}>
            {formatINR(report.netProfit)}
          </p>
          <p className={`inline-flex items-center gap-1 text-xs font-semibold ${statusAccent}`}>
            <StatusIcon className="w-3.5 h-3.5" />
            {report.statusLabel}
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-2">
          <p className="text-xs font-medium text-slate-500">Profit Margin</p>
          <p className={`text-2xl font-bold font-mono tabular-nums ${statusAccent}`}>
            {marginDisplay}
          </p>
          <p className="text-xs text-slate-500">
            {report.isZeroRevenue
              ? 'Division by zero prevented'
              : '(Net Profit / Revenue) × 100'}
          </p>
        </div>
      </section>

      {/* Visual Charts + Executive Summary */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between space-y-4">
          <div>
            <h3 className="text-base font-bold text-[#0A2540]">Revenue vs. Expenses Balance</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Proportional comparison in Indian Rupees (₹)
            </p>
          </div>

          <ReportComparisonChart
            revenue={report.revenue}
            expenses={report.expenses}
            netProfit={report.netProfit}
          />

          <div className="pt-4 border-t border-slate-100">
            <ProfitMarginGauge
              profitMarginPercent={report.profitMarginPercent}
              isZeroRevenue={report.isZeroRevenue}
            />
          </div>
        </div>

        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between space-y-6">
          <div className="space-y-3">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-base font-bold text-[#0A2540]">Executive Financial Summary</h3>
              <span className={`inline-flex items-center gap-1 text-xs font-semibold ${statusAccent}`}>
                <StatusIcon className="w-4 h-4" />
                {report.statusLabel}
              </span>
            </div>
            <p className="text-sm text-slate-700 leading-relaxed">{report.summaryText}</p>
          </div>

          {/* Formula Audit Trail */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
            <p className="text-xs font-semibold text-[#0A2540]">
              Calculation Verification (MBA Accounting Audit)
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono tabular-nums">
              <div className="space-y-1">
                <p className="text-slate-500">Net Profit = Revenue − Expenses</p>
                <p className="text-slate-900 font-semibold">
                  {formatINR(report.revenue)} − {formatINR(report.expenses)} ={' '}
                  {formatINR(report.netProfit)}
                </p>
              </div>
              <div className="space-y-1">
                <p className="text-slate-500">Profit Margin = (Net Profit / Revenue) × 100</p>
                <p className="text-slate-900 font-semibold">
                  {report.isZeroRevenue
                    ? 'Revenue is ₹0 → Undefined (N/A)'
                    : `(${formatINR(report.netProfit)} / ${formatINR(report.revenue)}) × 100 = ${report.profitMarginPercent!.toFixed(2)}%`}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Rule-Based Business Recommendations */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <div>
            <h3 className="text-base font-bold text-[#0A2540]">
              Practical Business Recommendations
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Generated using deterministic MBA rule-based profitability thresholds (offline
              rule engine, no live LLM inference)
            </p>
          </div>
          <span className="text-xs font-medium text-[#0D9488]">
            Rule Band · {report.statusLabel}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {report.recommendations.map((rec) => (
            <div
              key={rec.id}
              className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2"
            >
              <div className="flex items-center justify-between gap-2 text-xs">
                <span className="font-semibold text-[#0D9488]">{rec.category}</span>
                <span
                  className={`font-semibold ${
                    rec.priority === 'Critical'
                      ? 'text-[#DC2626]'
                      : rec.priority === 'Advisory'
                      ? 'text-[#D97706]'
                      : 'text-[#0A2540]'
                  }`}
                >
                  {rec.priority}
                </span>
              </div>
              <h4 className="text-sm font-bold text-[#0A2540] flex items-start gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#0D9488] shrink-0 mt-0.5" />
                <span>{rec.title}</span>
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed">{rec.detail}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
