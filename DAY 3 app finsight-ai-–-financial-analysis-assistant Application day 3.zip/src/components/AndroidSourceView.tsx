import React, { useState } from 'react';
import { Check, Copy, FileCode2, FolderTree, Smartphone } from 'lucide-react';
import { ANDROID_SOURCE_FILES, APK_BUILD_STEPS } from '../data/androidSourceFiles';

export function AndroidSourceView() {
  const [selectedPath, setSelectedPath] = useState(ANDROID_SOURCE_FILES[0].path);
  const [copiedPath, setCopiedPath] = useState<string | null>(null);

  const activeFile =
    ANDROID_SOURCE_FILES.find((f) => f.path === selectedPath) ?? ANDROID_SOURCE_FILES[0];

  const handleCopy = async (code: string, path: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedPath(path);
      setTimeout(() => setCopiedPath(null), 2000);
    } catch {
      // Clipboard fallback ignored if blocked in restricted iframe
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-[#0D9488]">
            Kotlin · Jetpack Compose · Material 3 · Navigation Compose
          </p>
          <h2 className="text-2xl sm:text-3xl font-bold text-[#0A2540] mt-1">
            Android Studio Source Code &amp; APK Guide
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            Complete Android Studio-compatible source files for FinSight AI and step-by-step
            instructions to build an installable APK.
          </p>
        </div>
      </div>

      {/* APK Build Guide */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <div className="flex items-center gap-2">
          <Smartphone className="w-5 h-5 text-[#0D9488]" />
          <h3 className="text-base font-bold text-[#0A2540]">
            How to Build &amp; Generate the Android APK in Android Studio
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          {APK_BUILD_STEPS.map((item) => (
            <div
              key={item.step}
              className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5"
            >
              <p className="font-mono text-xs font-bold text-[#0D9488]">Step {item.step}</p>
              <h4 className="text-xs font-bold text-[#0A2540]">{item.title}</h4>
              <p className="text-xs text-slate-600 leading-relaxed">{item.detail}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Source Explorer */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-4 space-y-2">
          <div className="flex items-center gap-2 px-2 py-1.5 border-b border-slate-100">
            <FolderTree className="w-4 h-4 text-[#0A2540]" />
            <span className="text-xs font-bold text-[#0A2540]">Android Project Files</span>
          </div>

          <div className="space-y-1">
            {ANDROID_SOURCE_FILES.map((file) => {
              const selected = file.path === activeFile.path;
              return (
                <button
                  key={file.path}
                  type="button"
                  onClick={() => setSelectedPath(file.path)}
                  className={`w-full text-left px-3 py-2.5 rounded-lg transition-colors cursor-pointer ${
                    selected
                      ? 'bg-[#0A2540] text-white'
                      : 'hover:bg-slate-100 text-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <FileCode2
                      className={`w-4 h-4 shrink-0 ${
                        selected ? 'text-teal-300' : 'text-slate-400'
                      }`}
                    />
                    <span className="text-xs font-semibold truncate">{file.fileName}</span>
                  </div>
                  <p
                    className={`text-[11px] truncate mt-0.5 pl-6 ${
                      selected ? 'text-slate-300' : 'text-slate-500'
                    }`}
                  >
                    {file.path}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        <div className="lg:col-span-8 bg-[#0A2540] text-slate-100 rounded-xl overflow-hidden flex flex-col">
          <div className="px-5 py-3.5 border-b border-white/10 flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="font-mono text-xs font-semibold text-teal-300">{activeFile.path}</p>
              <p className="text-xs text-slate-300 mt-0.5">{activeFile.summary}</p>
            </div>
            <button
              type="button"
              onClick={() => handleCopy(activeFile.code, activeFile.path)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#0D9488] hover:bg-[#0F766E] text-white text-xs font-semibold transition-colors cursor-pointer min-h-[36px]"
            >
              {copiedPath === activeFile.path ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  Copy File
                </>
              )}
            </button>
          </div>

          <pre className="p-5 overflow-x-auto text-xs font-mono leading-relaxed text-slate-100 max-h-[540px] overflow-y-auto">
            <code>{activeFile.code}</code>
          </pre>
        </div>
      </section>
    </div>
  );
}
