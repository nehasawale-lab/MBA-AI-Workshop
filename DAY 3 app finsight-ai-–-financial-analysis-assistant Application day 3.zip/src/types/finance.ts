export type AppScreen = 'welcome' | 'dashboard' | 'analysis' | 'reports' | 'android-code';

export interface FinancialInput {
  companyName: string;
  periodLabel: string;
  revenue: number;
  expenses: number;
}

export type MarginBand =
  | 'zero_revenue'
  | 'net_loss'
  | 'breakeven'
  | 'low_margin'
  | 'healthy_margin'
  | 'strong_margin';

export interface FinancialRecommendation {
  id: string;
  title: string;
  category: string;
  detail: string;
  priority: 'Critical' | 'Advisory' | 'Growth';
}

export interface FinancialReportResult {
  companyName: string;
  periodLabel: string;
  revenue: number;
  expenses: number;
  netProfit: number;
  isProfit: boolean;
  isLoss: boolean;
  isZeroRevenue: boolean;
  profitMarginPercent: number | null;
  expenseRatioPercent: number | null;
  marginBand: MarginBand;
  statusLabel: string;
  summaryText: string;
  recommendations: FinancialRecommendation[];
}

export interface MonthlySamplePoint {
  month: string;
  revenue: number;
  expenses: number;
}

export const SAMPLE_COMPANY_NAME = 'Aarav Precision Components Pvt. Ltd.';
export const SAMPLE_PERIOD_LABEL = 'FY 2025–26 · Annual Sample Statement';

export const SAMPLE_MONTHLY_SERIES: MonthlySamplePoint[] = [
  { month: 'Oct', revenue: 380000, expenses: 310000 },
  { month: 'Nov', revenue: 420000, expenses: 325000 },
  { month: 'Dec', revenue: 465000, expenses: 345000 },
  { month: 'Jan', revenue: 410000, expenses: 332000 },
  { month: 'Feb', revenue: 490000, expenses: 358000 },
  { month: 'Mar', revenue: 535000, expenses: 370000 },
];

export const SAMPLE_DASHBOARD_TOTALS = {
  revenue: SAMPLE_MONTHLY_SERIES.reduce((acc, m) => acc + m.revenue, 0),
  expenses: SAMPLE_MONTHLY_SERIES.reduce((acc, m) => acc + m.expenses, 0),
};

export const SAMPLE_EXPENSE_BREAKDOWN = [
  { label: 'Cost of Goods & Materials', sharePercent: 48 },
  { label: 'Payroll & Operations', sharePercent: 28 },
  { label: 'Rent, Utilities & Logistics', sharePercent: 15 },
  { label: 'Sales, Admin & Compliance', sharePercent: 9 },
];

export interface InputValidationResult {
  isValid: boolean;
  revenueError: string | null;
  expensesError: string | null;
  parsedRevenue: number;
  parsedExpenses: number;
}

export function formatINR(amount: number, showDecimals = false): string {
  const absFormatted = new Intl.NumberFormat('en-IN', {
    minimumFractionDigits: showDecimals ? 2 : 0,
    maximumFractionDigits: showDecimals ? 2 : 0,
  }).format(Math.abs(amount));

  return amount < 0 ? `-₹${absFormatted}` : `₹${absFormatted}`;
}

export function validateFinancialInputs(
  revenueRaw: string,
  expensesRaw: string
): InputValidationResult {
  const cleanRev = revenueRaw.replace(/,/g, '').trim();
  const cleanExp = expensesRaw.replace(/,/g, '').trim();

  let revenueError: string | null = null;
  let expensesError: string | null = null;

  const parsedRevenue = Number(cleanRev);
  const parsedExpenses = Number(cleanExp);

  if (cleanRev === '') {
    revenueError = 'Enter total company revenue in ₹ (enter 0 if no revenue was recorded).';
  } else if (!Number.isFinite(parsedRevenue) || Number.isNaN(parsedRevenue)) {
    revenueError = 'Revenue must be a valid numeric amount.';
  } else if (parsedRevenue < 0) {
    revenueError = 'Revenue cannot be negative. Enter 0 or a positive rupee value.';
  }

  if (cleanExp === '') {
    expensesError = 'Enter total company expenses in ₹.';
  } else if (!Number.isFinite(parsedExpenses) || Number.isNaN(parsedExpenses)) {
    expensesError = 'Expenses must be a valid numeric amount.';
  } else if (parsedExpenses < 0) {
    expensesError = 'Expenses cannot be negative. Enter 0 or a positive rupee value.';
  }

  return {
    isValid: revenueError === null && expensesError === null,
    revenueError,
    expensesError,
    parsedRevenue: Number.isFinite(parsedRevenue) ? parsedRevenue : 0,
    parsedExpenses: Number.isFinite(parsedExpenses) ? parsedExpenses : 0,
  };
}

export function calculateFinancialReport(input: FinancialInput): FinancialReportResult {
  const revenue = input.revenue;
  const expenses = input.expenses;
  const companyName = input.companyName.trim() || 'Your Enterprise';
  const periodLabel = input.periodLabel.trim() || 'Current Reporting Period';

  // Exact Formula 1: Net Profit = Revenue - Expenses
  const netProfit = revenue - expenses;
  const isZeroRevenue = revenue === 0;
  const isProfit = netProfit > 0;
  const isLoss = netProfit < 0;

  // Exact Formula 2: Profit Margin = (Net Profit / Revenue) * 100
  // Guard against division by zero when revenue is 0
  const profitMarginPercent = isZeroRevenue ? null : (netProfit / revenue) * 100;
  const expenseRatioPercent = isZeroRevenue ? null : (expenses / revenue) * 100;

  let marginBand: MarginBand;
  let statusLabel: string;
  let summaryText: string;

  if (isZeroRevenue) {
    marginBand = 'zero_revenue';
    statusLabel = expenses > 0 ? 'Zero Revenue · Operating Burn' : 'Zero Revenue · No Activity';
    summaryText =
      expenses > 0
        ? `${companyName} recorded ₹0 in revenue against ${formatINR(expenses)} in expenses during ${periodLabel}, resulting in a net operating loss of ${formatINR(Math.abs(netProfit))}. Profit margin is undefined because revenue is zero.`
        : `${companyName} recorded ₹0 in both revenue and expenses during ${periodLabel}. Profit margin cannot be computed when revenue is zero.`;
  } else if (netProfit < 0) {
    marginBand = 'net_loss';
    statusLabel = 'Net Operating Loss';
    summaryText = `${companyName} incurred a net loss of ${formatINR(Math.abs(netProfit))} (${profitMarginPercent!.toFixed(2)}% margin) for ${periodLabel}, as total expenses of ${formatINR(expenses)} exceeded revenue of ${formatINR(revenue)} by ${formatINR(Math.abs(netProfit))}.`;
  } else if (netProfit === 0) {
    marginBand = 'breakeven';
    statusLabel = 'Break-Even Position';
    summaryText = `${companyName} operated strictly at break-even for ${periodLabel}, with ${formatINR(revenue)} in revenue matching ${formatINR(expenses)} in total expenses (0.00% net margin).`;
  } else if (profitMarginPercent! < 10) {
    marginBand = 'low_margin';
    statusLabel = 'Positive · Thin Profit Margin';
    summaryText = `${companyName} generated a net profit of ${formatINR(netProfit)} on ${formatINR(revenue)} in revenue during ${periodLabel}. At ${profitMarginPercent!.toFixed(2)}%, the margin provides limited buffer against cost shocks.`;
  } else if (profitMarginPercent! <= 25) {
    marginBand = 'healthy_margin';
    statusLabel = 'Healthy Profitability';
    summaryText = `${companyName} achieved a healthy net profit of ${formatINR(netProfit)} and a ${profitMarginPercent!.toFixed(2)}% profit margin for ${periodLabel}. Expenses consumed ${expenseRatioPercent!.toFixed(1)}% of revenue.`;
  } else {
    marginBand = 'strong_margin';
    statusLabel = 'Strong Operating Margin';
    summaryText = `${companyName} delivered strong financial performance in ${periodLabel}, retaining ${profitMarginPercent!.toFixed(2)}% of revenue as net profit (${formatINR(netProfit)}) while keeping expenses at ${expenseRatioPercent!.toFixed(1)}% of revenue.`;
  }

  const recommendations = generateRuleBasedRecommendations({
    marginBand,
    revenue,
    expenses,
    netProfit,
    profitMarginPercent,
    expenseRatioPercent,
  });

  return {
    companyName,
    periodLabel,
    revenue,
    expenses,
    netProfit,
    isProfit,
    isLoss,
    isZeroRevenue,
    profitMarginPercent,
    expenseRatioPercent,
    marginBand,
    statusLabel,
    summaryText,
    recommendations,
  };
}

function generateRuleBasedRecommendations(params: {
  marginBand: MarginBand;
  revenue: number;
  expenses: number;
  netProfit: number;
  profitMarginPercent: number | null;
  expenseRatioPercent: number | null;
}): FinancialRecommendation[] {
  const { marginBand, revenue, expenses, netProfit } = params;

  switch (marginBand) {
    case 'zero_revenue':
      return [
        {
          id: 'zr-1',
          title: 'Prioritize Immediate Revenue Activation',
          category: 'Top-Line Recovery',
          priority: 'Critical',
          detail:
            expenses > 0
              ? `With ${formatINR(expenses)} in ongoing costs and ₹0 inflows, validate customer conversion bottlenecks and accelerate receivables or initial sales orders.`
              : 'Verify whether sales invoices for the period were deferred or unbilled, and log projected monthly revenue targets before committing fixed overheads.',
        },
        {
          id: 'zr-2',
          title: 'Contain Fixed Monthly Burn',
          category: 'Cost Governance',
          priority: 'Critical',
          detail:
            'Pause discretionary marketing, non-essential subscriptions, and variable overtime until recurring monthly revenue covers core fixed obligations.',
        },
        {
          id: 'zr-3',
          title: 'Establish Break-Even Runway Baseline',
          category: 'Working Capital',
          priority: 'Advisory',
          detail:
            'Calculate minimum monthly sales required to match fixed costs and maintain at least 3 months of liquid cash reserves.',
        },
      ];

    case 'net_loss': {
      const deficit = Math.abs(netProfit);
      const requiredCutPercent = expenses > 0 ? ((deficit / expenses) * 100).toFixed(1) : '0.0';
      return [
        {
          id: 'nl-1',
          title: 'Close the Operating Deficit Gap',
          category: 'Cost Restructuring',
          priority: 'Critical',
          detail: `Expenses exceed revenue by ${formatINR(deficit)}. Reaching break-even requires reducing total costs by ${requiredCutPercent}% or increasing top-line revenue by ${formatINR(deficit)}.`,
        },
        {
          id: 'nl-2',
          title: 'Audit High-Share Expense Heads',
          category: 'Margin Control',
          priority: 'Critical',
          detail:
            'Separate fixed overheads (rent, salaries) from variable unit costs (raw materials, logistics) and renegotiate vendor payment terms or bulk rates.',
        },
        {
          id: 'nl-3',
          title: 'Re-evaluate Unit Pricing & Product Mix',
          category: 'Pricing Strategy',
          priority: 'Advisory',
          detail:
            'Discontinue loss-making SKUs or discounted contracts where contribution margin is negative, and focus sales effort on higher-margin offerings.',
        },
      ];
    }

    case 'breakeven':
      return [
        {
          id: 'be-1',
          title: 'Build a Positive Safety Margin Above Break-Even',
          category: 'Profitability Target',
          priority: 'Advisory',
          detail: `Revenue (${formatINR(revenue)}) exactly equals expenses (${formatINR(expenses)}). Target at least a 10% net profit cushion (${formatINR(revenue * 0.1)}) to absorb unexpected GST, supplier, or seasonal fluctuations.`,
        },
        {
          id: 'be-2',
          title: 'Review Variable Cost Efficiency',
          category: 'Cost Discipline',
          priority: 'Advisory',
          detail:
            'Even a 5% reduction in operating expenses would immediately unlock ' +
            `${formatINR(expenses * 0.05)} in retained net profit without requiring additional sales volume.`,
        },
        {
          id: 'be-3',
          title: 'Track Contribution Margin by Line Item',
          category: 'Management Accounting',
          priority: 'Growth',
          detail:
            'Segment revenue by customer tier or product line to identify which segments generate surplus cash versus those merely covering overhead.',
        },
      ];

    case 'low_margin':
      return [
        {
          id: 'lm-1',
          title: 'Strengthen Thin Profit Buffer (< 10% Margin)',
          category: 'Margin Expansion',
          priority: 'Advisory',
          detail: `While profitable at ${formatINR(netProfit)}, a margin below 10% leaves the business vulnerable to raw material inflation or delayed customer payments. Aim to lift margin toward 12–15%.`,
        },
        {
          id: 'lm-2',
          title: 'Optimize Procurement & Overhead Leakage',
          category: 'Cost Governance',
          priority: 'Advisory',
          detail:
            'Audit recurring utility, logistics, and administrative expenses. Cutting 4% of operating costs would add ' +
            `${formatINR(expenses * 0.04)} directly to bottom-line profit.`,
        },
        {
          id: 'lm-3',
          title: 'Improve Receivables Turnover',
          category: 'Working Capital',
          priority: 'Growth',
          detail:
            'Enforce stricter credit periods (e.g., Net-15 or Net-30) so thin accounting profits convert into usable operating cash flow.',
        },
      ];

    case 'healthy_margin':
      return [
        {
          id: 'hm-1',
          title: 'Reinvest Surplus Wisely in Core Growth',
          category: 'Capital Allocation',
          priority: 'Growth',
          detail: `With ${formatINR(netProfit)} in net profit (10%–25% margin band), consider allocating 20–30% of surplus toward high-ROI customer acquisition or process automation.`,
        },
        {
          id: 'hm-2',
          title: 'Maintain Operating Expense Discipline as Scale Increases',
          category: 'Cost Control',
          priority: 'Advisory',
          detail:
            'Ensure overhead hiring and fixed lease commitments grow slower than revenue so operating leverage improves further next quarter.',
        },
        {
          id: 'hm-3',
          title: 'Build Working Capital & Tax Reserve',
          category: 'Compliance & Liquidity',
          priority: 'Advisory',
          detail:
            'Set aside estimated direct tax provisions and maintain an emergency liquidity reserve before distributing retained earnings.',
        },
      ];

    case 'strong_margin':
      return [
        {
          id: 'sm-1',
          title: 'Protect Competitive Moat & Pricing Power',
          category: 'Strategic Positioning',
          priority: 'Growth',
          detail: `Retaining over 25% of revenue (${formatINR(netProfit)}) signals strong pricing power and lean cost control. Monitor customer retention to sustain this premium margin.`,
        },
        {
          id: 'sm-2',
          title: 'Evaluate Capacity Expansion or Debt Reduction',
          category: 'Balance Sheet Strength',
          priority: 'Growth',
          detail:
            'Deploy excess free cash flow to retire high-interest working capital debt or fund capacity expansion with internal accruals rather than external borrowing.',
        },
        {
          id: 'sm-3',
          title: 'Standardize Quarterly Benchmarking',
          category: 'Financial Governance',
          priority: 'Advisory',
          detail:
            'Track return on capital employed (ROCE) alongside net profit margin to confirm that reinvested capital continues generating high returns.',
        },
      ];
  }
}
