import React, { useState } from 'react';
import { BarChart3, Calculator, Code2, FileText, Home } from 'lucide-react';
import {
  AppScreen,
  FinancialInput,
  FinancialReportResult,
  SAMPLE_COMPANY_NAME,
  SAMPLE_DASHBOARD_TOTALS,
  SAMPLE_PERIOD_LABEL,
  calculateFinancialReport,
} from './types/finance';
import { WelcomeScreen } from './components/WelcomeScreen';
import { DashboardScreen } from './components/DashboardScreen';
import { AnalysisScreen } from './components/AnalysisScreen';
import { ReportsScreen } from './components/ReportsScreen';
import { AndroidSourceView } from './components/AndroidSourceView';

const DEFAULT_ANALYSIS_INPUT: FinancialInput = {
  companyName: 'Apex SME Traders Pvt. Ltd.',
  periodLabel: 'FY 2025–26',
  revenue: 1250000,
  expenses: 940000,
};

export default function App() {
  const [activeScreen, setActiveScreen] = useState<AppScreen>('welcome');
  const [currentInput, setCurrentInput] = useState<FinancialInput>(DEFAULT_ANALYSIS_INPUT);
  const [report, setReport] = useState<FinancialReportResult>(() =>
    calculateFinancialReport({
      companyName: SAMPLE_COMPANY_NAME,
      periodLabel: SAMPLE_PERIOD_LABEL,
      revenue: SAMPLE_DASHBOARD_TOTALS.revenue,
      expenses: SAMPLE_DASHBOARD_TOTALS.expenses,
    })
  );
  const [isSampleReport, setIsSampleReport] = useState<boolean>(true);

  const navigateTo = (screen: AppScreen) => {
    setActiveScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCalculate = (input: FinancialInput) => {
    setCurrentInput(input);
    setReport(calculateFinancialReport(input));
    setIsSampleReport(false);
    navigateTo('reports');
  };

  const handleViewSampleReport = () => {
    setReport(
      calculateFinancialReport({
        companyName: SAMPLE_COMPANY_NAME,
        periodLabel: SAMPLE_PERIOD_LABEL,
        revenue: SAMPLE_DASHBOARD_TOTALS.revenue,
        expenses: SAMPLE_DASHBOARD_TOTALS.expenses,
      })
    );
    setIsSampleReport(true);
    navigateTo('reports');
  };

  const navItems: { id: AppScreen; label: string; icon: React.ElementType }[] = [
    { id: 'welcome', label: 'Welcome', icon: Home },
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'analysis', label: 'Analysis', icon: Calculator },
    { id: 'reports', label: 'Reports', icon: FileText },
    { id: 'android-code', label: 'Kotlin & APK', icon: Code2 },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC] text-[#0F172A]">
      {/* Sticky 3-Zone Top Bar */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Single-element wordmark */}
          <button
            type="button"
            onClick={() => navigateTo('welcome')}
            className="text-lg font-bold tracking-tight text-[#0A2540] whitespace-nowrap shrink-0 cursor-pointer"
          >
            FinSight AI
          </button>

          {/* Zone 2: Clean single-line typography nav links */}
          <nav
            aria-label="Primary Navigation"
            className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600"
          >
            {navItems.map((item) => {
              const active = activeScreen === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => navigateTo(item.id)}
                  className={`py-1 border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? 'border-[#0D9488] text-[#0A2540] font-semibold'
                      : 'border-transparent hover:text-[#0A2540] hover:border-slate-300'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Single primary action */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={() =>
                navigateTo(activeScreen === 'analysis' ? 'android-code' : 'analysis')
              }
              className="px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-[#0A2540] hover:bg-[#163A5F] rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[40px]"
            >
              {activeScreen === 'analysis' ? 'Kotlin Source' : 'Calculate (₹)'}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 pb-24 md:pb-12">
        {activeScreen === 'welcome' && (
          <WelcomeScreen
            onGetStarted={() => navigateTo('dashboard')}
            onNavigate={navigateTo}
          />
        )}

        {activeScreen === 'dashboard' && (
          <DashboardScreen
            onOpenAnalysis={() => navigateTo('analysis')}
            onViewSampleReport={handleViewSampleReport}
          />
        )}

        {activeScreen === 'analysis' && (
          <AnalysisScreen
            initialInput={currentInput}
            onCalculate={handleCalculate}
          />
        )}

        {activeScreen === 'reports' && (
          <ReportsScreen
            report={report}
            isSampleReport={isSampleReport}
            onEditInputs={() => navigateTo('analysis')}
            onBackToDashboard={() => navigateTo('dashboard')}
          />
        )}

        {activeScreen === 'android-code' && <AndroidSourceView />}
      </main>

      {/* Quiet Footer (Desktop) */}
      <footer className="hidden md:block border-t border-slate-200 bg-white no-print">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-4 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500">
          <span>FinSight AI · Financial Analysis Assistant for MBA Finance &amp; Accounting</span>
          <span>Formulas: Net Profit = Revenue − Expenses · Profit Margin = (Net Profit / Revenue) × 100</span>
        </div>
      </footer>

      {/* Mobile Bottom Navigation Bar (Android Material 3 ergonomics) */}
      <nav
        aria-label="Mobile Screen Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200 grid grid-cols-5 h-16 no-print"
      >
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = activeScreen === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => navigateTo(item.id)}
              className={`flex flex-col items-center justify-center gap-1 min-h-[44px] cursor-pointer ${
                active ? 'text-[#0D9488] font-semibold' : 'text-slate-500'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] leading-none whitespace-nowrap">{item.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
